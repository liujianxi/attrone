<template>
<div id="l-p-i">
    <div class="main">
		<img class="head-img" src="https://s.1-1dr.com/static/mobile/img/1_3.png" />
		<div class="show-content">
			<h1 class="first-el">大暑节气到，各地“食俗”知多少？</h1>
			<div class="author"><span>4小时前</span></div>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;七月份进入了一年中最热的节气——小暑和大暑，天气炎热起来，特别是进入大暑之后，高温潮湿的气候让人感觉不舒服，是以民间有“小暑不算热，大暑三伏天”的说法。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;盛夏之时，由于天气酷热潮湿，因此老人、儿童及一些体质虚弱的人容易中暑，一般出现全身乏力、头昏、头痛、心悸、胸闷、口渴、大量出汗、注意力不集中、四肢麻木等症状时，多为中暑先兆。易医堂在此提醒，一旦发现自己或其他人出现中暑先兆，要立刻离开高温环境，选择阴凉通风的地方休息，喝一些含盐分的清凉饮料。还可以在额头和太阳穴处涂些风油精等，或服用人丹、十滴水、藿香正气水等药物。</p>	
			<h2>大暑小暑，祛湿解暑</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;入伏之后，天气开始炎热，在使用空调避暑降温时，一定要注意温度不要设定过低，一般不应低于27 ℃，不要长时间开着空调，室内要经常通风。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;中医历来有“冬病夏治”的说法，大暑是全年温度最高、阳气最盛的时期，一些冬季发作的慢性疾病，如慢性支气管炎、肺气肿、支气管哮喘、反复感冒、风湿痹痛、慢性腹泻等，此时如果在医生的指导下进行调养和治疗，可以起到事半功倍的效果。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;此季节暑湿之气易入侵人体，在饮食方面应选择一些具有清热解暑、化湿健脾作用的食物，如薏苡仁、赤小豆、绿豆、茯苓、山药、南瓜、冬瓜、西瓜、乌梅、番茄等。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;大暑节气的民俗主要体现在吃的方面，本时节的民间饮食习俗大致分为两种：一种是吃凉性食物消暑；有些地方的人们则习惯在大暑时节吃热性食物。下面，随易医堂探访各地大暑时节的“食俗”吧。</p>
			<h2>各地“食俗”知多少</h2>
			<h2>广东大暑吃“仙草”</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;广东很多地方在大暑时节有“吃仙草”的习俗。仙草又名凉粉草、仙人草，唇形科仙草属草本植物，是重要的药食两用植物资源。由于其神奇的消暑功效，被誉为“仙草”。将其茎叶晒干后，可以做成烧仙草，广东一带叫凉粉，是一种消暑的甜品。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;烧仙草本身也可入药。民谚：六月大暑吃仙草，活如神仙不会老。烧仙草是台湾著名的小吃之一，有冷、热两种吃法。烧仙草的外观和口味均类似粤港澳地区流行的另一种小吃龟苓膏，也同样具有清热解毒的功效。</p>
			<br />
			<div style="position:relative; padding-top:69.7%;">
				<img style="position:absolute;top:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/14.png"  />
			</div>
			<br />
			<h2>福建莆田吃荔枝“过大暑”</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;福建莆田人在大暑时节有吃荔枝、羊肉和米糟的习俗，叫做“过大暑”。荔枝含有葡萄糖和多种维生素，富有营养价值，所以吃鲜荔枝可以滋补身体。先将鲜荔枝浸于冷井水之中，大暑时刻一到便取出品尝。这一时刻吃荔枝，最惬意、最滋补。于是，有人说大暑吃荔枝，其营养价值和吃人参一样高。
温汤羊肉是莆田独特的风味小吃和高级菜肴之一。把羊宰后，去毛卸脏，整只放进滚汤的锅里翻烫，捞起放入大陶缸中，再把锅内的滚汤注入，泡浸一定时间后取出。吃时，把羊肉切成片片，肉肥脆嫩，味鲜可口。
米糟是将米饭拌和白米曲让它发酵，透熟成糟；到大暑那天，把它划成一块块，加些红糖煮食，据说可以“大补元气”。在大暑到来那天，亲友之间，常以荔枝、羊肉互赠。</p>
			<br />
			<div style="position:relative; padding-top:69.7%;">
				<img style="position:absolute;top:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/16.png"  />
			</div>
			<br />
			<h2>台湾大暑吃凤梨</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;大暑期间，我国台湾有吃凤梨的习俗，民间认为这个时节的凤梨最好吃。加上凤梨的闽南语发音和“旺来”相同，所以也被用来作为祈求平安吉祥、生意兴隆的象征。</p>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;另外，大暑前后就是农历六月十五日，台湾也叫“半年节”，由於农历六月十五日是全年的一半，所以在这一天拜完神明后全家会一起吃“半年圆”，半年圆是用糯米磨成粉再和上红面搓成的，大多会煮成甜食来品尝，象征意义是团圆与甜蜜。。</p>
			<br />
			<div style="position:relative; padding-top:69.7%;">
				<img style="position:absolute;top:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/18.png"  />
			</div>
			<br />
			<h2>相关菜谱</h2>
			<h2>大暑可饮生姜大枣汤</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;《皇帝内经》记载“春夏养阳，秋冬养阴”，夏天时，人们可用生姜、大枣和红糖一起熬煮着吃，可以养阳、养脾胃和补血。红糖性温，有补血功效，平时也可多喝（糖尿病患者或特殊疾病患者除外）。</p>
			<br />
			<div style="position:relative; padding-top:69.7%;">
				<img style="position:absolute;top:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/19.png"  />
			</div>
			<br />
			<h2>大暑喝喝老鸭汤</h2>
			<p>&nbsp;&nbsp;&nbsp;&nbsp;大暑时，天气炎热，鸭子在水中生活，鸭肉性偏凉，中医认为，其有滋五脏之阳、清虚劳之热、补血行水、养胃生津的功效。因此，在大暑这天，人们不妨做一下老鸭汤喝</p>
			<br />
			<div style="position:relative; padding-top:69.7%;">
				<img style="position:absolute;top:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/20.png"  />
			</div>
			<br />
		</div>
	</div>
	<s-header type="0" 
		:transparent="headerTran"
		:title="headerTit"
		:hasTc="false"
		></s-header>
</div>
</template>
<script>
	import SHeader from './SHeader.vue'
	import {isApp} from '../util/common.js';
	export default {
		components: {
			SHeader,
		},
		data(){
			return{
				showShare:false,
				headerTran: true,
				headerTit: ''
			}
		},
		computed: {
			isShowBtn : function(){
				if(isApp(window)){
					return false
				}else{
					return true;
				}
			},
			showConStyle: function(){
				return{
	                'padding-top': (isApp(window) ? '1.06666667rem' : '0')
            	}				
			}
		},
		mounted(){
			document.querySelector('body').scrollTop = 0;		//还原滚动条位置
		},
		activated(){
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;		//还原滚动条位置
			try{
				window.current_page  = 'longprotectintro';
				var bd = document.querySelector('body');
				var he = document.querySelector('.head-w #header');
				var self = this;
				document.onscroll = function(){
					// console.log(bd.scrollTop);
					if(bd.scrollTop +  40 >= screen.width/750*480){	//图片刚好消失，显示头部
						if(self.headerTran) {
							self.headerTran = false; 
							self.headerTit='健康小知识';
						}
					} else {
						if(!self.headerTrans) {
							self.headerTran = true;
							self.headerTit='';
						}
					}
				}
			}catch(e){
				console.error(e.message);
			}
			//发起异步请求检查用户登录
			// https.post('/json/GetUserInfo');
		},
		deactivated(){
			document.onscroll = null;
		},
		methods: {
			clickShare(){
				this.showShare = true;
			},
			clickCancel(){
				this.showShare = false;
			}
		}
	}
</script>
<style scoped lang="scss">
	@import "../assets/css/global.scss";
	
	.main{
		color: #999;
		word-break: break-word;
		font-size: px2rem(30px);
		font-weight: 400;
		line-height: 1.7;
		background-color: white;
		padding-bottom: 1.6rem;
		text-align: left;
	}

	.first-el{
		margin:0;
		/*padding: px2rem(20px) 0;*/
		padding-top:px2rem(107px);
	}
	.show-content{
		padding-left: px2rem(23px);
		padding-right: px2rem(23px);
		text-align: left;
	}
	#l-p-i {
		text-align: left;
		background-color: white;
	}
	
	body {
		text-align: left;
		margin: 0;
	}
	
	h1 {
		text-align: left;
		padding-top:0;
		font-size: px2rem(48px);
		color: #292d33;
		line-height: px2rem(65px);
	}
	
	h2 {
		text-align: left;
		margin:0;
		font-size: px2rem(36px);
		color:#ccc;
		padding-top:px2rem(78px);
		padding-bottom:px2rem(50px);
	}
	
	ol {
		padding: 0;
		margin-left: px2rem(40px);
		margin-bottom: px2rem(20px);
	}
	
	li {
		margin-bottom: px2rem(10px);
		line-height: px2rem(30px);
	}
	
	
	.image-package {
		padding-bottom: px2rem(25px);
		width: px2rem(700px);
		height: auto;
		width: 100%;
		text-align: center;
	}
	
	.image-package img {
		width: 100%;
		height: 100%;
		max-width: 100%;
		height: auto;
		vertical-align: middle;
		border: 0;
		transition: all .25s ease-in-out;
		box-sizing: border-box;
	}
	
	.head-img {
		display: block;
		width: 100%;
		/*height: px2rem(498px);*/
	}
	#header{
		background-color: rgba(0, 0, 0,0)!important;
	}
	.author{
		margin-top:px2rem(45px);
		margin-bottom: px2rem(78px);
		font-size: px2rem(30px);
		text-align: right;
	}
	.btn_fix_bot{
		height:px2rem(98px);
		font-size: px2rem(36px);
		color:#fff;
	}
</style>