<template>
    <div id="profile">
        <s-header type="5" title="个人信息" v-on:backCallFather="rightCallFather"></s-header>
        <div class="main">
            <div class="tou-x">
                <span>头像</span>
                <div class="r" @click="clickHeadImg">
                    <img :src="userVo.headImgUrl"></img>
                    <i class="r-more"></i>
                </div>
            </div>
            <div class="dls">
                <dl>
                    <dd>
                        <span>姓名</span>
                        <div class="r name">
                            <input type="text" :value="userVo.name" v-model="userVo.name"></input>
                            <i></i>
                        </div>
                    </dd>
                    <dd @click="clickSex()">
                        <span>性别</span>
                        <div class="r">
                            <span>{{userVo.sex | sexFilter}}</span>
                            <i class="r-more"></i>
                        </div>
                    </dd>
                    <dd @click="clickDate()">
                        <span>出生日期</span>
                        <div class="r">
                            <span v-if="userVo.birthday">{{userVo.birthday}}</span>
                            <span v-else>未设置</span>
                            <i class="r-more"></i>
                        </div>
                    </dd>
                </dl>
            </div>
        </div>
        <!-- <input type="hidden" v-model="username"> -->

        <!-- 性别选择 -->
        <mt-popup v-model="showSexPanel" :closeOnClickModal="true" position="bottom">
            <div class="pp-content">
                <div class="btns" slot="header">
                    <button type="button" class="ctbtn" @click="cancelSex()">取消</button>
                    <button type="button" class="ctbtn" @click="sureSex()">确定</button>
                </div>
                <div>
                    <mt-picker :slots="sexSlots" @change="onSexChange"></mt-picker>
                </div>
            </div>
        </mt-popup>

        <!-- 时间选择 -->
        <mt-datetime-picker ref="birthdayPicker" type="date" :startDate="startDate" :endDate='endDate' year-format="{value} 年" month-format="{value} 月" date-format="{value} 日" v-model="dateVal" @confirm="sureDate">
        </mt-datetime-picker>
    </div>
</template>
<script>
import SHeader from './SHeader.vue'
import { wxChooseImage, wxUploadImage, isEmpty, isEmptyStr } from '../util/common.js'
import { Toast, Picker, DatetimePicker, Indicator, Popup } from 'mint-ui';
import http from '../service/api.js'

var tmpSexVal;

export default {
    components: { SHeader, DatetimePicker, Popup },
    data() {
        return {
            startDate: new Date('1900/01/01'),
            endDate: new Date(),
            showSexPanel: false,   //显示性别选择层
            showDatePanel: false,   //显示日期选择层
            sexSlots: [{
                flex: 1,
                values: ['男', '女'],
                className: 'slot1',
                textAlign: 'center'
            }],
            userVo: {
                name: '',
                headImgUrl: '',
                headImgId: '',
                phone: '',
                birthday: '',
                sex: ''
            },
            sexVal: '',
            dateVal: '',
            headImgLink: '',   //微信图片链接
            isTemp:'',
        }
    },
    activated() {
        // console.warn('come in!');
        var self = this;
        let urlParamObj = this.$route.query.userVo;
        // console.log('activated come in!' + JSON.stringify(urlParamObj));

        if (urlParamObj) {
            self.userVo = urlParamObj;
        }
    },
    methods: {
        //返回既提交
        rightCallFather() {
            let self = this;
            Indicator.open({
                text: '正在保存个人信息...',
                spinnerType: 'fading-circle'
            });

            //收集请求参数
            let params = {
                name: self.userVo.name,
                headImg: self.userVo.headImgId,
                sex: self.userVo.sex,
                birthday: self.userVo.birthday
            };
            //发发送请求
            http.post('/json/UpdateUserInfo', params).then(function(res) {
                Indicator.close();
                if (res.errorCode == 0) {
                    Toast({ message: '个人信息修改成功！' });
                    self.$router.push({ path: '/me' });
                } else {
                    Toast({ message: res.msg });
                }
            }, function(res) {
                Toast({ message: res.msg });
            });
        },
        //确定日期选择
        sureDate(value) {
            // this.dateVal = value.toString();
            this.userVo.birthday = value.format("yyyy-MM-dd");
            this.showDatePanel = false;
        },
        //确定性别
        sureSex() {
            var realNum = 0;
            let self=this;
            this.sexVal = self.isTemp;
            console.log(self.isTemp);
            if (this.sexVal == '男') {
                realNum = 1;
            } else if (this.sexVal == '女') {
                realNum = 2;
            } else {
                realNum = 0;
            }
            this.userVo.sex = realNum;
            // console.info('this.userVo.sex:'+this.userVo.sex + ',this.sexVal:'+this.sexVal);
            this.showSexPanel = false;
        },
        //取消性别选择
        cancelSex() {
            this.showSexPanel = false;
        },
        //点击日期
        clickDate() {
            this.dateVal = this.userVo.birthday;
            this.$refs.birthdayPicker.open();
            this.showDatePanel = true;
        },
        //点击性别
        clickSex() {
            this.showSexPanel = true;
        },
        clickHeadImg() {
            let self = this;
            try {
                wxChooseImage(window.wx).then(function(res) {
                    var mediaId = res.localIds[0];
                    self.userVo.headImgUrl = mediaId;
                    // console.info('Common.wxChooseImage back!mediaId:' + mediaId);
                    // self.showIdCardImg(mediaId);//不需要
                    Indicator.open({
                        text: '正在上传头像...',
                        spinnerType: 'fading-circle'
                    });
                    return wxUploadImage(window.wx, mediaId);
                }).then(function(res) {
                    // console.info('Common.wxUploadImage back!' + JSON.stringify(res));
                    var serverId = res.serverId;
                    // console.info('Common.wxUploadImage back!' + JSON.stringify(res));
                    return http.post('/json/GetImageToWx', { mediaId: serverId, type: 'headImg' });
                }).then(function(res) {
                    // console.info('GetImageToWx come in!' + JSON.stringify(res));
                    Indicator.close();
                    if (res.errorCode == 0) {
                        self.userVo.headImgId = res.body.imgId;
                        Toast({ message: '头像上传' + res.msg });
                    }
                }).catch(function(res) {
                    Indicator.close();
                    Toast({ message: res.msg });
                });
            } catch (e) {
                console.error(e.message);
            }
        },
        onSexChange(picker, values) {
            let self=this;
            self.isTemp = values[0];
        },
        //点击遮罩层事件
        clickMaskCall() {
            //隐藏所有弹窗
            this.showSexPanel = false;
            this.showDatePanel = false;
        },
    }
}
</script>
<style scoped lang="scss">
@import "../assets/css/global.scss";

.main {
    font-size: px2rem(32px);
    text-align: left;
}

.r {
    float: right;

    .r-more {
        display: inline-block;
        width: px2rem(14px);
        height: px2rem(26px);
        background: url('https://s.1-1dr.com/static/mobile/img/wechat/more.png') no-repeat;
        background-size: 100% auto;
        float: right;
        margin-top: px2rem(37px);
        margin-left: px2rem(40px);
    }
}

.name {
    input {
        /*height: px2rem(98px);*/
        padding: 0;
        font-size: px2rem(32px);
        text-align: right;
        height: 100%;
    }
    i {
        display: inline-block;
        width: px2rem(30px);
        height: px2rem(31px);
        background: url('https://s.1-1dr.com/static/mobile/img/wechat/mko_edit.png') no-repeat;
        background-size: 100% auto;
        float: right;
        margin-top: px2rem(35px);
        margin-left: px2rem(24px);
    }
}

.tou-x {
    height: px2rem(180px);
    line-height: px2rem(180px);
    padding: 0 px2rem(30px);
    margin-bottom: px2rem(20px);
    background-color: #fff;

    .r-more {
        margin-top: px2rem(77px);
    }
    img {
        display: inline-block;
        vertical-align: middle;
        width: px2rem(118px);
        height: px2rem(120px);
    }
}

.dls {
    background-color: #fff;
    dl {
        margin-left: px2rem(30px);

        dd {
            padding-right: px2rem(30px);
            height: px2rem(98px);
            line-height: px2rem(98px);
            border-bottom: 1px solid $separate-color;
        }
    }
}

.pp-content {
    width: px2rem(750px);

    .ctbtn {
        display: inline-block;
        width: 50%;
        text-align: center;
        line-height: 40px;
        font-size: pxrem(16px);
        color: #26a2ff;
        background-color: #fff;
    }
    .btns {
        overflow: hidden;
        border-bottom: solid 1px #eaeaea;
    }
    .ctbtn:first-child {
        float: left;
    }
    .ctbtn:last-child {
        float: right;
    }
}
</style>