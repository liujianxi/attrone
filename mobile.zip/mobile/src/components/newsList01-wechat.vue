<template>
	<div id="l-p-i">
		<div class="main">
			<img class="head-img" src="https://s.1-1dr.com/static/mobile/img/1_2.png" />
			<div class="show-content" :style="showConStyle">
				<h1 class="first-el">人人都知道的免疫系统——外来病原体</h1>
				<div class="author">
					<span>4小时前</span>
				</div>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;目前很多人知道增强免疫力，有助于身体对抗外来原体（细菌、病毒），也就是俗称的“抵抗力”。但事实上，免疫力太强，有时不见得是好事。以乙型肝炎为例，当乙肝病毒入侵肝脏时，成人因为免疫力比较强，为了要杀死躲在肝脏细胞里的病毒，会强力动员免疫系统，进而可能引起严重破坏肝细胞发生爆发性肝炎，甚至死亡。相反地，小朋友的免疫力较差，免疫系统无法将病毒完全歼灭，反倒不会发作得很厉害，不将病毒杀死，因此这孩子就变成了乙肝病毒的携带者。</p>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/1.png" />
				</div>
				<p style="margin-top:20px">&nbsp;&nbsp;&nbsp;&nbsp;另外，身体的免疫系统必须会分辨入侵者还是自己人。如果免疫系统弄错对象，或者敌我不分，就有可能起内哄，不但攻击免疫系统（正常免疫细胞），还可能伤及无辜（身体组织或器官），这就是所谓的“自体免疫疾病”。常见的有红斑性狼疮、类风湿性关节炎、僵直性脊柱炎、干燥症等。经常有病患误以为是因免疫力不足所造成的，所以常问医生该吃什么增强免疫力，或者私下进补，吃健康食品，期望借着强化免疫系统治好疾病。其实对体质易引发自体免疫问题的人，食用灵芝、蜂胶、花粉等往往反会使问题火上加油。</p>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;维持免疫系统平衡比强化重要，人体是很复杂的，当有外来威胁，身体会自动激活，调节各系统（比如内分泌、免疫系统），睡得好、饮食均衡、精神饱满，其实就是免疫系统处在一种稳定平衡状态。</p>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/2.png" />
				</div>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;如果硬要透过吃补药、打胎盘素荷尔蒙，或者猛吃某种食物，过度操控，可能会打破免疫系统原来的平衡状态，身体需费更大功夫去消化、矫正这多余营养素或不需要的成分，其结果会适得其反。</p>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;除了好好吃饭睡觉，传染病流行时少去公共场所，接种疫苗、常保心情乐观稳定，对于免疫系统有正面帮助。</p>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/3.png" />
				</div>
				<p style="margin-top: 40px;">&nbsp;&nbsp;&nbsp;&nbsp;接种疫苗是人类提高保全系统防护能力的重要发明。利用疫苗事先刺激免疫系统产生抗体，等到真正病毒来袭，立刻上场作战反击，控制感染。</p>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;从离婚、丧偶到考试等相关研究显示，压力与负面情绪会打乱免疫平衡。乐观态度在面对重大压力时特别重要。美国加州大学洛杉矶分校一项对法律系学生的研究发现，乐观的学生，体内负责免疫反应、消灭病毒的Ｔ细胞，比悲观的学生多。因此当你心情不好时，建议找朋友聊聊。</p>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;诚然，现代医学已很发达，但人类在病毒面前，有时仍相当被动。从大规模的流行病毒到司空见惯的感冒，尚没有一种药能保证我们长治久安。值此关键时刻，积极行动起来，有效维持免疫系统的平衡至关重要。</p>

				<h2>策略一：吃饱早饭</h2>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/4.png" />
				</div>

				<p style="margin-top: 20px;">&nbsp;&nbsp;&nbsp;&nbsp;荷兰医学研究人员最近做了这样一个实验，他们将被测试者分成两组。一组每天吃早饭，每份早饭的热量为1200卡路里，另一组不吃。通过比较发现，早饭吃得早吃得饱，血管内的γ-干扰素，一种天然抗病毒蛋白的含量提高了450%，而不吃早餐的话，伽马干扰素的数量下降了17%。</p>

				<h2>策略二：巧用工作压力</h2>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/6.png" />
				</div>

				<p>&nbsp;&nbsp;&nbsp;&nbsp;工作压力是坏事，但当坏事不可避免地来临，不要消极躲避，而是要积极利用。美国俄亥俄州立大学的研究人员做了这样一个实验，他们将34位被测试者分成两半，一半参加一个12分钟的记忆力测试，另一半观看一部长达12分钟的手术录像。结果，参加记忆力测试的那组在完成测试后，体内slgA免疫蛋白含量显著上升。而另一组被测试者体内的slgA含量则有所下降。这个实验结果告诉我们，坏事可以变好事，当压力来临时，我们可以利用它增强自身的免疫力。主持这项研究的波西博士认为，“身体处于一定工作压力下，体内的自身免疫系统会被激活并作出相应反应，这是人体为免遭伤害而自发实施的一种正常保护措施。”但“如果工作量太大，人体免疫系统在持续应对一段时间后，就会崩溃。”</p>
				<h2>策略三：喝下午茶</h2>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/7.png" />
				</div>

				<p>&nbsp;&nbsp;&nbsp;&nbsp;又是下午4点，想去楼下喝杯咖啡吗？好是好，不过，有没有想过，如果改喝杯绿茶的话，你的身体会感激你的。加拿大研究人员发现，茶叶中含一种叫作EGCG的化合物，它能有效阻止病毒自我复制。而在所有茶叶中，绿茶含有最多的EGCG。所以，当你发现自己有感冒苗头时，赶紧喝点绿茶。就像那些含咖啡因的感冒药一样，绿茶能遏制病毒的进一步发作。最佳的喝茶方法是：先将水煮沸，然后将茶叶放入，浸泡满10分钟后再饮用。</p>
				<h2>策略四：每天睡足</h2>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/8.png" />
				</div>

				<p>&nbsp;&nbsp;&nbsp;&nbsp;加州大学洛杉矶分校的研究人员通过实验发现，如果睡眠时间减少40%（比如，睡眠时间从7小时减少到4小时），那么此人的自身免疫系统抵抗能力将下降50%。如果想保证自身免疫系统完全，要想睡得好，躺在被窝里时不能穿得太多，一条短裤一件汗衫最合适。因为穿得过多不利于你体温自我调节，从而会影响睡眠质量并降低自身免疫系统的抵抗能力。</p>
				<h2>策略五：经常运动</h2>

				<div style="position:relative; padding-top:69.7%;">
					<img style="position:absolute;top:0;left:0;" class="head-img" src="https://s.1-1dr.com/static/mobile/img/9.png" />
				</div>

				<p>&nbsp;&nbsp;&nbsp;&nbsp;马萨诸塞大学研究人员对547名被测试者做了一个为期一年的观察。结果显示，那些最爱运动的被测试者得上呼吸道感染的机率要比整天呆在屋子里的人少２５％。此次实验使他们相信，运动能增强人体免疫力，其中的部分原因是，通过锻炼人体会提高生成血液白细胞的能力。领导此次实验的查尔斯•马修思博士认为，“积极参加锻炼会带来两个好处：一是得感冒的可能性减少；二是一旦感冒会比以前恢复得更快。”实验报告最后还建议，每天应进行60到90分钟的锻炼，运动量要适中，既包括力量锻炼也要耐力锻炼。</p>

			</div>
		</div>
		<s-header type="0" :transparent="headerTran" :title="headerTit" :hasTc="false"></s-header>
	</div>
</template>
<script>
import SHeader from './SHeader.vue'
import { isApp } from '../util/common.js'
import { checkLogin} from '../util/common.js'
export default {
	components: {
		SHeader,
	},
	data() {
		return {
			showShare: false,
			headerTran: true,
			headerTit: ''
		}
	},
	computed: {
		isShowBtn: function() {
			if (isApp(window)) {
				return false
			} else {
				return true;
			}
		},
		showConStyle: function() {
			return {
				'padding-top': (isApp(window) ? '1.06666667rem' : '0')
			}
		}
	},
	mounted() {
		document.querySelector('body').scrollTop = 0;		//还原滚动条位置
	},
	activated() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;		//还原滚动条位置
		try {
			window.current_page = 'longprotectintro';
			var bd = document.querySelector('body');
			var he = document.querySelector('.head-w #header');
			var self = this;
			document.onscroll = function() {
				// console.log(bd.scrollTop);
				if (bd.scrollTop + 40 >= screen.width / 750 * 480) {	//图片刚好消失，显示头部
					if (self.headerTran) {
						self.headerTran = false;
						self.headerTit = '健康小知识';
					}
				} else {
					if (!self.headerTrans) {
						self.headerTran = true;
						self.headerTit = '';
					}
				}
			}
		} catch (e) {
			console.error(e.message);
		}
		//发起异步请求检查用户登录
		// https.post('/json/GetUserInfo');
	},
	deactivated() {
		document.onscroll = null;
	},
	methods: {
		clickShare() {
			this.showShare = true;
		},
		clickCancel() {
			this.showShare = false;
		}
	}
}
</script>
<style scoped lang="scss">
@import "../assets/css/global.scss";

.main {
	color: #999;
	word-break: break-word;
	font-size: px2rem(30px);
	font-weight: 400;
	line-height: 1.7;
	background-color: white;
	padding-bottom: 1.6rem;
	text-align: left;
}

.show-content {
	padding-left: px2rem(23px);
	padding-right: px2rem(23px);
}

.first-el {
	margin: 0;
	/*padding: px2rem(20px) 0;*/
	padding-top: px2rem(107px);
}

#l-p-i {
	text-align: left;
	background-color: white;
}

body {
	text-align: left;
	margin: 0;
}

h1 {
	text-align: left;
	padding-top: 0;
	font-size: px2rem(48px);
	color: #292d33;
}

h2 {
	text-align: left;
	margin: 0;
	font-size: px2rem(36px);
	color: #ccc;
	padding-top: px2rem(78px);
	padding-bottom: px2rem(50px);
}

ol {
	padding: 0;
	margin-left: px2rem(40px);
	margin-bottom: px2rem(20px);
}

li {
	margin-bottom: px2rem(10px);
	line-height: px2rem(30px);
}


.image-package {
	padding-bottom: px2rem(25px);
	width: px2rem(700px);
	height: auto;
	width: 100%;
	text-align: center;
}

.image-package img {
	width: 100%;
	height: 100%;
	max-width: 100%;
	height: auto;
	vertical-align: middle;
	border: 0;
	transition: all .25s ease-in-out;
	box-sizing: border-box;
}

.head-img {
	width: 100%;
	/*height: px2rem(500px);*/
	display: block;
}

#header {
	background-color: rgba(0, 0, 0, 0)!important;
}

.author {
	margin-top: px2rem(45px);
	margin-bottom: px2rem(78px);
	font-size: px2rem(30px);
	text-align: right;
}

.btn_fix_bot {
	height: px2rem(98px);
	font-size: px2rem(36px);
	color: #fff;
}
</style>