var a = {
  "code": 0, "message": "请求成功", "data": {
    "carousel": {
      "list": [{
        "content": "1",
        "picUrl": "https://beta.images.appollo.haitun.hk/banner-01.png",
        "type": "product",
        "title": "英文banner 01",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "2",
        "picUrl": "https://beta.images.appollo.haitun.hk/banner-01.png",
        "type": "product",
        "title": "banner 02",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }]
    }
    ,
    "active": {
      "list": [{
        "content": "2",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-1.png",
        "type": "product",
        "title": "active 1",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "3",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-2.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "2",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-1.png",
        "type": "product",
        "title": "active 1",
        "originPrice": -1,
        "marketPrice": 10,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "3",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-2.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": 21,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }]
    }
    ,
    "flashSale": {
      "list": [{
        "content": "5",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-1.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "6",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-2.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "7",
        "picUrl": "https://beta.images.appollo.haitun.hk/active-1.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }], "beginTime": 1022542215111, "endTime": 1022542215111
    }
    ,
    "newArrivals": {
      "list": [{
        "content": "7",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-01.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "4",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "4",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": 21,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }]
    }
    ,
    "lifeStyle": {
      "list": [{
        "content": "21",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-01.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "22",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "23",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-03.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "24",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-04.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }]
    }
    ,
    "recommend": {
      "list": [{
        "content": "21",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-01.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "22",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "23",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-03.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "24",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-04.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "21",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-01.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "22",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "23",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-03.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "24",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-04.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "21",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-01.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "22",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-02.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "23",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-03.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }, {
        "content": "24",
        "picUrl": "https://beta.images.appollo.haitun.hk/life-style-04.png",
        "type": "product",
        "title": "active 2",
        "originPrice": -1,
        "marketPrice": -1,
        "minRealPrice": -1,
        "maxRealPrice": -1
      }]
    }
  }
}






















<template>
  <div id="wish">
    <p class="rangPdding fontSize textAlign bgWhite borderBottom titleClass">My WishList</p>
    <!--<mt-button type="danger" style="margin-top: 100px">default</mt-button>-->


    <mt-loadmore :top-method="loadTop" :top-status.sync="topStatus">
      <ul class="currentPaying nameAddress" style="margin-bottom: 10rem;">
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
      </ul>
      <div slot="top" class="mint-loadmore-top">
        <span v-show="topStatus !== 'loading'" :class="{ 'rotate': topStatus === 'drop' }">↓</span>
        <span v-show="topStatus === 'loading'">Loading...</span>
      </div>
    </mt-loadmore>


    <mt-loadmore :bottom-method="loadBottomUse"
                 :bottom-all-loaded="allUseLoad" :bottomPullText='bottomText'
                 ref="loadmore">
      <div class="tab-list" v-for='item in useScoreLog'>
        <div class="tab-list-top">
          <span class="tab-name">{{item.remark}}</span>
          <span class="tab-num">{{item.score}}</span>
        </div>
        <div class="tab-list-bottom">
          <span class="tab-time">{{item.operateTime}}</span>
          <span class="tab-class">{{item.recordTypeName}}</span>
        </div>
      </div>
    </mt-loadmore>


  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/cart.css";

  .logMoney {
    text-decoration: line-through;
    color: #999;
  }

  .wishPosition {
    position: absolute;
    bottom: 0;
    left: 0;
  }

</style>


<script type="text/javascript">
  import Vue from 'vue'

  import {Loadmore, Toast, Button} from 'mint-ui';

  Vue.component(Loadmore.name, Loadmore, Button.name, Button, Toast);

  export default {
    data () {
      return {
        'page': 1,
        "bottomAllLoaded":false,
        allLoaded:false,
        topPullText:'yyyyyyyyyyyyy',
        topDropText:'ccccccccccccccccccccccccccc',
      }
    },
    computed: {},
    methods: {
      loadTop(id) {

        this.$refs.loadmore.onTopLoaded(id);
        console.log(this.page++);
      },
      loadBottom(id){
        console.log(666);

        this.$refs.loadmore.onBottomLoaded(id);
      }
    },
    activated: function () {
      Toast('提示语');
      this.topPullText='99999999999'

    },
    components: {
      Loadmore
    }
  }


</script>













