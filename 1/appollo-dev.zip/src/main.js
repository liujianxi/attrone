// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import 'mint-ui/lib/style.css'
import COMMON from './assets/basejs/common'

import VueI18n from 'vue-i18n'
Vue.use(VueI18n);

const messages = {
  en: require('./assets/lang/en.json'),
  zh: require('./assets/lang/zh.json'),
  ar: require('./assets/lang/ar.json')
};
let setLang = 'en';
let langIndex = COMMON.getCookie('lang')?COMMON.getCookie('lang'):undefined;
Vue.prototype.gLang=langIndex;

if (langIndex) {
  switch (langIndex) {
    case 1:
      setLang = 'en'
      break;
    case 2:
      setLang = 'ar'
      break;
    case 3:
      setLang = 'zh'
      break;
  }
}else {
  setLang='ar'
}

let i18n = new VueI18n({
  locale: setLang, // set locale
  messages, // set locale messages
});

// new Vue({ i18n }).$mount('#cart');


console.log(666666);


Vue.config.productionTip = false;


export default new Vue({
  el: '#app',
  data(){
    return {
      tabShowOrhide: true,
      eventHub: new Vue()
    }
  },
  router,
  template: '<App/>',
  components: {App},

  methods: {
    checkLogin: function () {

      console.log("这里写checkLogin");
    }
  },
  watch: {
    $route: function (to) {
      //监听路由变化，判断是否显示tab和checkLogin
      console.log(to);
      console.log(messages);
    }
  },
  i18n
}).$mount('#app');

// app.$i18n.locale = 'ar'


// if (module.hot) {
//   module.hot.accept([require('./assets/lang/en.json'), require('./assets/lang/zh.json'),require('./assets/lang/ar.json')], function () {
//     i18n.setLocaleMessage('en', require('./assets/lang/en.json').default),
//     i18n.setLocaleMessage('zh', require('./assets/lang/zh.json').default),
//     i18n.setLocaleMessage('ar', require('./assets/lang/ar.json').default)
//
//   })
// }



