<template>
  <div id="app" style="height: 100%;">
    <!--<transition>-->

    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <!--</transition>-->

    <my-component v-if="tabBoolean"></my-component>
  </div>
</template>


<style>
  @import "assets/basesass/base.scss";

  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }

</style>


<script>
  import tab from './components/tabs.vue';
  import COMMON from './assets/basejs/common'

  export default {
    name: 'app',
    data(){
      return {
        tbIdex: 0,
        tabBoolean: true,
        luhaimin: false,
        isLang: 1

      }
    },
    watch: {
      "$route": "watchPathFn"
    },
    methods: {
      tabClick: function (index) {
        this.tbIdex = index;
        let aNode = document.getElementsByTagName('a');

      },
      watchPathFn() {

        let tempName = this.$route.name;
        if (tempName != 'home' && tempName != 'cart' && tempName != 'wish' && tempName != 'categories' && tempName != 'account') {
          this.tabBoolean = false;
        } else {
          this.tabBoolean = true;
        }

      }
    },
    components: {
      'my-component': tab
    },
    mounted: function () {
      this.watchPathFn();
      let cLang = COMMON.getCookie('lang') ? COMMON.getCookie('lang') : 2;

      if (cLang === 2) {
        let appNode = document.getElementById('app');

        appNode.setAttribute('dir', 'rtl')
      }


      if (cLang) {
//          this.isLang=cLang-1;
      }
    }
  }
</script>


