const requestUrl = 'https://beta.api.appollo.haitun.hk';


import Vue from 'vue'
import VueResource from 'vue-resource'

Vue.use(VueResource);


const CONFIG = {
  get: function (api, par) {

    return Vue.http.get(requestUrl + api, par).then(res => {
      return res.body
    })
  },
  post: function (api, par) {
    return Vue.http.post(requestUrl + api,par).then(res => {

      return res
    })
  }
};

export default CONFIG;
