<template>
  <div id="myinfo">
    <myinfo-back class="titleClass" :message="childTitle" :toPath="toBackPath"></myinfo-back>

    <ul class="accountBottom marginTopTitle marginBottom">
      <li class="myOrder" v-for="(item,index) of selectTitle">
        <!--<router-link :to='item.link' query="{name:'uuuu'}">-->
        <router-link :to="{'path':item.link,query:{name:item.msg}}">
          <span v-show="index!=1" :class="{afterEle:true,beforeEle:index==0}"></span>
          <span
            :class="{headPortrait:index==0,lineHeight:index==0,inlneBlock:index==0, headPortrait:index==0,  floatLeft:index==0}"></span>
          <span :class="{headTitle:index==0}">{{item.name}}</span>
          <span class="floatLeft currentSet grayColor">{{item.msg}}</span>
        </router-link>
      </li>
    </ul>

    <input type="file" accept="image/*;capture=camera">

    <ul class="accountBottom marginBottom">
      <li class="myOrder" v-for="(item,index) of myBaseIfo">
        <router-link :to="item.link">
          <span :class="{afterEle:true}"></span>
          <span>{{item.name}}</span>
          <span class="floatLeft currentSet grayColor">{{item.msg}}</span>
        </router-link>
      </li>


      <li class="myOrder" @click="sexFlagFn()">

        <span class="afterEle"></span>
        <span>جنس</span>
        <span class="floatLeft currentSet grayColor">{{sltSex}}</span>
        <ul :class="{selectSex:true, controlSltSex:sexFlag}">
          <li>Select Gender</li>
          <li @click="selectSex(1)">
            <label id="female">
              <input type="radio" name="sltSex" id="female">
              <span>Female</span>
            </label>

          </li>
          <li @click="selectSex(2)">
            <label id="male">
              <input id="male" type="radio" name="sltSex">
              <span>Male</span>
            </label>


          </li>
        </ul>

      </li>
    </ul>

    <ul class="accountBottom marginBottom">
      <li class="myOrder" v-for="(item,index) of changePassword">
        <router-link :to="item.link">
          <span :class="{afterEle:true}"></span>
          <span>{{item.name}}</span>
          <span class="floatLeft currentSet grayColor">{{item.msg}}</span>
        </router-link>
      </li>
    </ul>

    <myinfo-logout :buttonName="buttonName" :buttonPath="buttonPath"></myinfo-logout>

  </div>
</template>

<style>
  @import "../css/mysass.css";
  @import "../css/user.css";
  @import "../css/cart.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import InfoBackBtn from './share/back.vue'
  import InfoBtn from './share/button.vue'
  let selectTitle = [
    {name: "رئيس صورة", link: '/home', msg: ''},
    {name: "اسم المستخدم", link: '', msg: '2345678@163.com'},
    {name: "اسم العرض", link: '/displayName', msg: '卢海民'}
  ];
  let myBaseIfo = [
    {name: "بلد", link: '/language', msg: 'Hong Kong'},
    {name: "عيد الميلاد", link: '', msg: '2000-09-09'}
//    {name: "جنس", link: '/home', msg: 'Male'}
  ];
  let changePassword = [
    {name: "جنس", link: '/changePassword', msg: ''}
  ];


  export default {
    data () {
      return {
        "childTitle": "My Info",
        "toBackPath": '',
        "selectTitle": selectTitle,
        "myBaseIfo": myBaseIfo,
        "changePassword": changePassword,
        "buttonName": "Log Out",
        "buttonPath": '/account',
        "sltSex": 'Femal',
        "sexFlag": true
      }
    },
    methods: {
      selectSex: function (num) {
        if (num == 1) {
          this.sltSex = 'Female';
        } else {
          this.sltSex = 'Male';
        }

      },
      sexFlagFn: function () {

        if (this.sexFlag) {
          this.sexFlag = false;
        } else {
          this.sexFlag = true;
        }

      }
    },
    created: function () {
    },
    mounted: function () {
    },
    components: {
      "myinfo-back": InfoBackBtn,
      "myinfo-logout": InfoBtn,
    }
  }
</script>
