<template>
  <div id="newaddress">
    <address-title class="titleClass" :message="forgotTitle"></address-title>

    <p class="addressDone rangPdding">Save</p>

    <ul class="nameAddress">
      <li v-for="item of msgTitle" class="ovflowHidden borderBottom paddingBottom">
        <label id="firstName">
          <p class="inlneBlock">
            <span class="lineHeight">*</span>
            <span>{{item.name}}:</span>
          </p>
          <input class="newAddress" type="text" name="" id="firstName">
        </label>
      </li>
    </ul>

    <div class="marginTop bgWhite ovflowHidden rangPdding">
      <span style="line-height: 3.2rem;">Set as default adress</span>
      <label style="position: relative;" id="switchCheckbox" class="ovflowHidden inlneBlock floatLeft">
        <input class="wishAndDel" type="checkbox" v-model="selectAdress" id="switchCheckbox">
        <span class="floatLeft inlneBlock switch"></span>
      </label>
    </div>





  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/cart.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import AddressBook from './share/back.vue'
  import AddressBtn from  './share/button.vue'

  let newMsg=[
    {name:"First Name"},
    {name:"Last Name"},
    {name:"Country"},
    {name:"State/Pro/Region"},
    {name:"City"},
    {name:"Address1"},
    {name:"Address2"},
    {name:"Zip/Postal Code"},
    {name:"Mobile Phone Number"},
    {name:"Alternate Phone Number"},
  ];

  export default {
    data () {
      return {
        forgotTitle: 'Add New Address',
        titles: '',
        msgTitle:newMsg,
        selectAdress:true
      }
    },
    computed: {},
    methods: {},
    components: {
      "address-title": AddressBook,
      "address-btn": AddressBtn,
    }
  }


</script>

