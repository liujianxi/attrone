<template>
  <div id="accountlanguage">
    <set-back class="titleClass" :message="childTitle" :toPath="toBackPath"></set-back>


    <ul class="accountBottom marginTopTitle">
      <li @click="selectLanguage(index)" class="myOrder" v-for="(item,index) of selectLang">
        <span class="languageName">{{item.name}}</span>
        <span :class="{floatLeft:true,sarLanguageOn:selectDot==index,sarLanguage:selectDot!=index}">st</span>
      </li>
    </ul>


  </div>
</template>

<style>
  @import "../css/mysass.css";
  @import "../css/user.css";
</style>

<script type="text/javascript">

  import MainJs from '../main'
  import SetBack from './share/back.vue'
  import COMMON from '../assets/basejs/common'

  let selectLang = [
    {name: "English", link: '/home', msg: '', code: 0},
    {name: "العربية", link: '/home', msg: 'USD', code: 1},
    {name: "中文", link: '/home', msg: 'USD', code: 3}
  ];


  export default {
    data () {
      return {
        "childTitle": 'Language',
        "toBackPath": '',
        "selectLang": selectLang,
        "cLang":1,
        "selectDot": 1

      }
    },
    computed: {},
    methods: {
      selectLanguage: function (index) {
        this.selectDot = index;
        COMMON.setCookie('lang', index+1, 1000);

//        this.cLang = COMMON.getCookie('lang');
//        if (this.cLang) {
//          this.selectDot=this.cLang*1;
//          alert(this.cLang)
//        }


        location.reload();


      }
    },
    activated:function () {
      let langIndex = COMMON.getCookie('lang')?COMMON.getCookie('lang'):undefined;


      if(langIndex){
          this.selectDot=langIndex-1;
      }

    },
    components: {
      "set-back": SetBack
    }
  }


</script>

