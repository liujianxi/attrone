<template>
  <div id="account">
    <mt-actionsheet
      :actions="actions"
      cancelText="取消了---"
      v-model="sheetVisible">
    </mt-actionsheet>


    <div class="accountTop">
      <p class="setMsg">
        <span :class="{ltrFl:gLang!==2}">
          <router-link to="/set">
          </router-link>
        </span>
        <span v-show="gLang===2">xx</span>
        <!--消息管理 暂时隐藏了css-->
      </p>

      <p class="welcome">{{$t('message.logIn.wel')}}</p>
      <router-link style="height: auto;" :to="{path:'/loginRegister',query:{log:1}}">
        <p class="loginSignUp">{{$t('message.logIn.login')}} / {{$t('message.logIn.signUp')}}</p>
      </router-link>
    </div>

    <!--我的订单-->
    <ul class="accountMyOrder">
      <li>
        <router-link class="myOrder" to="/myorder">
          <span :class="{afterEle:true,ltrFr:gLang!==2,ltrDegr:gLang!==2}"></span>
          <span :class="{ltrLh:gLang!==2}">{{$t('message.logIn.order')}}</span>
          <span :class="{myOrderIcon:true,ltrFl:gLang!==2,ltrMgr:gLang!==2}">dd</span>
        </router-link>
      </li>
      <li class="myOrder orderStatus">
        <p>{{$t('message.logIn.unPaid')}}</p>
        <p>{{$t('message.logIn.pre')}}</p>
        <p>{{$t('message.logIn.shi')}}</p>
      </li>
    </ul>


    <!--个人管理-->
    <ul class="accountBottom">
      <!--<li class="myOrder">-->
      <!--<span class="afterEle"></span>-->
      <!--<span>My WishList</span>-->
      <!--<span class="myWish">dd</span>-->
      <!--</li>-->
      <li class="myOrder">
        <router-link to="/addressbook">
          <span :class="{afterEle:true,ltrFr:gLang!==2,ltrDegr:gLang!==2}"></span>
          <span :class="{myAdress:true,ltrFl:gLang!==2,ltrMgr:gLang!==2}">dd</span>
          <span :class="{ltrLh:gLang!==2}">{{$t('message.logIn.adBk')}}</span>

        </router-link>

      </li>
      <li class="myOrder">
        <span :class="{afterEle:true,ltrFr:gLang!==2,ltrDegr:gLang!==2}"></span>
        <span :class="{myShare:true,ltrFl:gLang!==2,ltrMgr:gLang!==2}">dd</span>
        <span :class="{ltrLh:gLang!==2}">{{$t('message.logIn.share')}}</span>

      </li>
      <li class="myOrder">
        <router-link to="/contactus">
          <span :class="{afterEle:true,ltrFr:gLang!==2,ltrDegr:gLang!==2}"></span>
          <span :class="{myContact:true,ltrFl:gLang!==2,ltrMgr:gLang!==2}">dd</span>
          <span :class="{ltrLh:gLang!==2}">{{$t('message.logIn.contact')}}</span>

        </router-link>

      </li>
    </ul>

  </div>
</template>

<style scoped>
  @import "../css/ltr.css";
  @import "../css/user.css";
</style>


<script type="text/javascript">
  import Vue from 'vue'

  import {Actionsheet} from 'mint-ui';
  Vue.component(Actionsheet.name, Actionsheet);

  import IUY from '../assets/basejs/common'


  IUY.setCookie("xie", {id: 1255, name: 'youkeshu'}, 5);
  //IUY.clearCookie("luhaimin");
  let a = IUY.getCookie('xie');
  if (a === undefined) {
    alert('没设置cookie');
  }

  console.log(a, '取到的cookie');

  export default {
    data () {
      return {
        tabs: '',
        sheetVisible: true,     //mint-ui的ActonSheet的--隐藏
        actions: [{              //actions是obj的arr
          name: '拍照',
          method: this.uyyyyy    //不需要加（），若加会自动运行
        }]

      }
    },
    computed: {},
    methods: {},
    activated: function () {

    },
    mounted: function () {

    }
  }


</script>

