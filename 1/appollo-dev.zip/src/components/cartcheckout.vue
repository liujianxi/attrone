<template>
  <div id="cart">
    <!--自定义头部组件-->
    <title-back class="titleClass" :message="childTitle" :toPath="toBackPath"></title-back>

    <!--个人信息地址-->
    <div class="nameAddress">
      <h4>李小龙</h4>
      <div class="address">
        <div>李小龙的一生是短暂的,但却如同一颗耀眼的彗星划过国际武坛的上空,对现代技击术和电影表演艺术的发展作出了巨大的贡献
<p>01234556789</p>
        </div>

        <span class="listAfter"></span>
      </div>

    </div>

    <!--正在购买的商品-->
    <ul class="currentPaying">
      <li class="currentPayingFlex">
        <div class="payImg">
          <img draggable="true" src="" alt="">
        </div>
        <div class="PayDetail">
          <p class="googsTitle">
            JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
          <p>Color : Red</p>
          <p>$ {{amount}}</p>
          <span class="goodsQuantity clearBorder">X{{quantity}}</span>
        </div>
      </li>
      <li class="currentPayingFlex">
        <div class="payImg">
          <img src="" alt="">
        </div>
        <div class="PayDetail">
          <p class="googsTitle">
            JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
          <p>Color : Red</p>
          <p>$ {{amount}}</p>
          <span class="goodsQuantity clearBorder">X{{quantity}}</span>
        </div>
      </li>
    </ul>

    <!--收货需要时间-->
    <div class="expressNeedTime">
      <div style="overflow:hidden;">
        <p class="expressTitle">Express delivery</p>
        <span class="expressMoney">$5.0</span>
      </div>

      <p class="needWorkingdays">5-7  Working Days</p>


      <div>
        <div class="orderSummary">Order Summary :</div>
        <div style="overflow: hidden;">
          <span class="productTotal">Product Total</span>
          <span class="expressMoney">$29</span>
        </div>
        <div style="overflow: hidden;">
          <span class="productTotal">Shipping Charge</span>
          <span class="expressMoney">${{shippingCharge}}</span>
        </div>
        <div>
          <span class="orderSummary">Order Total :</span>
          <span class="expressMoney orderSummary">${{totalPay}}</span>
        </div>
      </div>
    </div>


    <div class="footerButton">

      <div class="goPayTop">
        <span>Sub Total : </span>
        <span class="payMoney">${{totalPay}}</span>
      </div>
      <util-button :buttonName="buttonName" :buttonPath="buttonPath"></util-button>

    </div>


  </div>
</template>

<style>
  @import "../css/cart.css";
</style>


<script type="text/javascript">
  import Back from './share/back.vue'
  import Button from './share/button.vue'
  export default {
    data () {
      return {
        childTitle: '',
        amount: '',
        quantity: 1,
        toBackPath: '/cart',
        totalPay: 0,
        expressDelivery: 5.5,
        shippingCharge: 0,
        buttonName: 'Continue',
        buttonPath: '/payment'
      }
    },
    methods: {
      loadMsg: function () {
        let receiveMsg = this.$route.query;

        this.childTitle = receiveMsg.title;
        this.shippingCharge = this.expressDelivery * receiveMsg.quantity; //总邮费
        this.quantity = receiveMsg.quantity;    //数量
        this.totalPay = receiveMsg.totalPay;
        this.amount = receiveMsg.amount;    //总金额

        console.log('从cart跳转到checkout调用');
      }
    },
    watch: {
      '$route': 'loadMsg'
    },
    mounted: function () {
      this.loadMsg()

    },
    components: {
      'title-back': Back,
      'util-button': Button
    }


  }
</script>
