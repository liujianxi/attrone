<template>
  <div id="tab">
    <ul id="tabs">
      <li @click="tabClick(index)" v-for="(item,index) in $t('message.tabs')">
        <!--<router-link :to="item.link">-->
        <p
          :class="{home:index==0&&tbIdex!=0,home_on:index==0&&tbIdex==0,categories:index==1,categories_on:index==1&&tbIdex==1,search:index==2,search_on:index==2&&tbIdex==2,cart:index==3,cart_on:index==3&&tbIdex==3,account:index==4,account_on:index==4&&tbIdex==4}"></p>
        {{item.name}}

            <span v-show="index==3&&tbIdex!=3" class="cartBadge">1</span>

        <!--</router-link>-->
      </li>
    </ul>
  </div>
</template>

<script type="text/javascript">
  let language = [
    {name: "Home", code: 0, link: '/home'},
    {name: "Categories", code: 1, link: '/categories'},
    {name: "Wish", code: 2, link: '/wish'},
    {name: "Cart", code: 3, link: '/cart'},
    {name: "Account", code: 4, link: '/account'}
  ];


  export default{

    name: 'tab',
    data(){
      return {
        lg: language,
        tbIdex: 0
      }
    },
    methods: {
      tabClick: function (index) {
        this.tbIdex = index;
        let aNode = document.getElementsByTagName('a');

        if (index == 0) {
          this.$router.push({path: '/home'})
        }
        if (index == 1) {
          this.$router.push({path: '/categories'})
        }
        if (index == 2) {
          this.$router.push({path: '/wish'})
        }
        if (index == 3) {
          this.$router.push({path: '/cart'})
        }
        if (index == 4) {
          this.$router.push({path: '/account'})
        }


      }
    },
    mounted: function () {
      let tempName = this.$route.name.toLocaleUpperCase()
      for (let i = 0; i < this.lg.length; i++) {
        if (this.$route.name == this.lg[i].name.toLowerCase()) {
          this.tbIdex = i;
        }
      }
    }
  }
</script>

<style>

  a {
    color: #333;
  }

  .router-link-active {
    /*color: #ff8000;*/
  }

  #tabs {
    border-top: 1px solid #b2b2b2;
    position: fixed;
    z-index: 999;
    background: #fff;
    bottom: 0;
    width: 100%;
  }

  #tabs li {
    display: inline-block;
    text-align: center;
    width: 20%;
    position: relative;
    font-size: 1.2rem;
    padding: 5px 0px;
  }

  #tabs li p {
    display: block;
    width: 2rem;
    height: 2rem;
    margin: 0 auto;
  }

  .home {
    background: url("../assets/img/icon-home.png") center no-repeat;
  }

  .home_on {
    background: url("../assets/img/icon-home_on.png") center no-repeat;
  }

  .categories {
    background: url("../assets/img/icon-Category.png") center no-repeat;
  }

  .categories_on {
    background: url("../assets/img/icon-Category_on.png") center no-repeat;
  }

  .search {
    background: url("../assets/img/heart.png") center no-repeat;
  }

  .search_on {
    background: url("../assets/img/heart_on.png") center no-repeat;
  }

  .cart {
    background: url("../assets/img/icon-cart.png") center no-repeat;
  }

  .cart_on {
    background: url("../assets/img/icon-cart_on.png") center no-repeat;
  }

  .account {
    background: url("../assets/img/icon-Account.png") center no-repeat;
  }

  .account_on {
    background: url("../assets/img/icon-Account_on.png") center no-repeat;
  }

  .home, .home_on, .categories, .categories_on, .search, .search_on, .cart, .cart_on, .account, .account_on {
    -webkit-background-size: 100% 100%;
    background-size: 100% 100%;
  }

  .cartBadge {
    position: absolute;
    right: 23%;
    top: 0.4rem;
    width: 1.5rem;
    border-radius: 50%;
    text-align: center;
    background: red;
    color: #fff;
  }
</style>
