<template>
  <div id="myorder">
    <myorder-title :message="forgotTitle"></myorder-title>
    <ul class="myorderRouter" style="overflow: hidden;">
      <li @click="myorderClick(index)" :class="{titleActive:titleIndex==index}" v-for="(item,index) of titles">
        <router-link :class="{fontBlack:true,routerLinkctive:titleIndex==index}" :to="item.link">{{item.name}}
        </router-link>
      </li>
    </ul>


    <!--child-->
    <keep-alive>
      <router-view></router-view>
    </keep-alive>


  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/cart.css";
  @import "../css/myorder.css";
</style>

<script type="text/javascript">
  import MyOrder from './share/back.vue';

  let myorderTitle = [
    {name: "All", link: '/myorder/all', rtName: 'myorderall', code: 0},
    {name: "Unpaid", link: '/myorder/unpaid', rtName: 'myorderunpaid', code: 1},
    {name: "Preparing", link: '/myorder/preparing', rtName: 'myorderpreparing', code: 2},
    {name: "Shipped", link: '/myorder/shipped', rtName: 'myordershipped', code: 3},
    {name: "Review", link: '/myorder/review', rtName: 'myorderreview', code: 4},
  ];

  export default {
    data () {
      return {
        forgotTitle: 'My Order',
        titles: myorderTitle,
        titleIndex: 0,
        routerName: ''
      }
    },
    computed: {},
    mounted: function () {

    },
    methods: {
      myorderClick: function (index) {
        this.titleIndex = index;
      }
    },
    activated: function () {
//        title判断
      for (let i in myorderTitle) {
        if (myorderTitle[i]['rtName'] == this.$route.name) {
          this.titleIndex = myorderTitle[i]['code'];
        }
      }
      this.routerName = this.$route.name
    },
    components: {
      "myorder-title": MyOrder
    }
  }


</script>


