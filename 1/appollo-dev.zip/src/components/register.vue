<template>
  <div id="register">

    <div class="lgInputBox">
      <input id="email" class="inputSty inputUtilStyle" type="text" placeholder="Email Address">
    </div>


    <div class="lgInputBox">
      <input class="inputStyPsd inputUtilStyle" type="password" placeholder="Password">
    </div>

    <div class="lgInputBox">
      <input class="inputStyPsd inputUtilStyle" type="password" placeholder="Re-enter Password">
    </div>

    <div class="loginSubmit">SING UP</div>




  </div>
</template>
<style>
  @import "../css/user.css";
</style>

<script type="text/javascript">

    export default {
        data () {
            return {
            }
        },
        computed:{

        },
        methods:{


        }
    }







</script>


