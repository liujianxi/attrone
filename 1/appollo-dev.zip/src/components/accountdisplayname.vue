<template>
  <div id="displayName">
    <contact-title :message="message" :toPath="toPath"></contact-title>
    <!--内容部分-->

    <ul class="marginTop">
      <li class="marginBottom">
        <label id="originalPassword">
          <input type="text" v-model="youName" id="originalPassword" class="myInput" placeholder="最开始显示原始名字"/>
        </label>
      </li>

    </ul>


    <contact-submit :buttonName="buttonName" :buttonPath="buttonPath"></contact-submit>


  </div>
</template>


<style>
  @import "../css/mysass.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import ContactUs from './share/back.vue'
  import ContactSubmit from './share/button.vue'


  export default {
    data () {
      return {
        "message": 'تغيير كلمة السر',
        "toPath": '',
        "buttonName": "Submit",
        "buttonPath": '/home',
        "youName": ''
      }
    },
    computed: {},
    methods: {},
    components: {
      'contact-title': ContactUs,
      'contact-submit': ContactSubmit
    },
    activated: function () {
      this.youName = this.$route.query.name;
      let youNameNode = document.getElementById('originalPassword');
      youNameNode.focus();
    }
  }


</script>

