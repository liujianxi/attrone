<template>
  <div id="contactUs">
    <contact-title :message="message" :toPath="toPath"></contact-title>
    <!--内容部分-->

    <label id="youTopic">
      <input type="text" class="myInput marginTop marginBottom" id="youTopic" placeholder="you topic"/>
    </label>

    <label id="myTextarea">
  <textarea id="myTextarea" class="contactUsMsg rangPdding" placeholder="Your Massage">
  </textarea>
    </label>
    <p class="bgWhite rangPdding marginTop marginBottom grayColor">4567890@qq.com</p>


    <contact-submit :buttonName="buttonName" :buttonPath="buttonPath"></contact-submit>


    <ul>
      <li class="marginBottom rangPdding" v-for="(item,index) of titleJson">
        <p>
          <span></span>
          <span>
            <a v-if="index==0" href="mailTo:4456789@qq.com">{{item.title}}</a>
            <a v-if="index==1" href="tel:18682217821">{{item.title}}</a>
            <a v-if="index==2" href="sms:18682217821">{{item.title}}</a>
          </span>
        </p>

        <span class="grayColor">{{item.msg}}</span>
      </li>
    </ul>


  </div>
</template>


<style>
  @import "../css/mysass.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import ContactUs from './share/back.vue'
  import ContactSubmit from './share/button.vue'

  let titleJson = [
    {title: "E-mail: youkeshu@aplo.com", msg: 'Typical response time is within 24 hours'},
    {title: "Phome: 18682217821", msg: 'Typical response time is within 24 hours'},
    {title: "Live Chat: Chat Now", msg: 'Typical response time is within 24 hours'},
  ]


  export default {
    data () {
      return {
        "message": 'Contact Us',
        "toPath": '',
        "buttonName": "Submit",
        "buttonPath": '/home',
        "titleJson": titleJson
      }
    },
    computed: {},
    methods: {},
    components: {
      'contact-title': ContactUs,
      'contact-submit': ContactSubmit
    }
  }


</script>

