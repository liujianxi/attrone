<template>
  <div id="changePassword">
    <contact-title :message="message" :toPath="toPath"></contact-title>
    <!--内容部分-->

    <ul>
      <li class="marginBottom">
        <label id="originalPassword">
          <input type="password" id="originalPassword" class="myInput" placeholder="Original Password"/>
        </label>
      </li>

      <li class="marginBottom">
        <label id="originalPassword">
          <input type="password" id="originalPassword" class="myInput" placeholder="New Password"/>
        </label>
      </li>

      <li class="marginBottom">
        <label id="originalPassword">
          <input type="password" id="originalPassword" class="myInput" placeholder="Confirm Password"/>
        </label>
      </li>
    </ul>


    <contact-submit :buttonName="buttonName" :buttonPath="buttonPath"></contact-submit>


  </div>
</template>


<style>
  @import "../css/mysass.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import ContactUs from './share/back.vue'
  import ContactSubmit from './share/button.vue'


  export default {
    data () {
      return {
        "message": 'تغيير كلمة السر',
        "toPath": '',
        "buttonName": "Submit",
        "buttonPath": '/home'
      }
    },
    computed: {},
    methods: {},
    components: {
      'contact-title': ContactUs,
      'contact-submit': ContactSubmit
    }
  }


</script>

