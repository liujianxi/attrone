<template>
  <div id="myorderall">

    <h2>All</h2>

  </div>
</template>
<style>

</style>

<script type="text/javascript">
  import MyOrder from './share/back.vue';

  export default {
    data () {
      return {

      }
    },
    computed: {},
    mounted: function () {

    },
    methods: {},


  }


</script>


