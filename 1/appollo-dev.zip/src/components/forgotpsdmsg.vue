<template>
  <div id="forgotmsg">
    <forgot-title :message="forgotTitle"></forgot-title>
    <p class="sendEmail rangPdding">We send a password reset link to the following email address:
<span class="emailMsg">{{email}}</span>
    </p>
    <p class="sendEmail">Please follow the link and reset your password tithin 24 hours.</p>
    <forgot-close class="marginTop paddingTop" :buttonName="close" :buttonPath="closePath"></forgot-close>
      </div>
</template>
<style>

  @import "../css/mysass.css";
  @import "../css/cart.css";

  .sendEmail {
    color: #666;
    background: #ffffff;
    line-height: 2.3rem;
  }

  .emailMsg {
    color: #000;
  }

</style>

<script type="text/javascript">
  import ForgotTitle from './share/back.vue';
  import CloseBtn from './share/button.vue'

  export default {
    data () {
      return {
        forgotTitle: 'Forgot Password',
        email: '',
        close:"Close To Login",
        closePath:'/loginRegister'
      }
    },
    computed: {},

    mounted: function () {

      this.email = this.$route.query.email, 'pppp';


    },
    methods: {},
    components: {
      "forgot-title": ForgotTitle,
      "forgot-close": CloseBtn
    },

  }


</script>


