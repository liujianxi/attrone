<template>
  <div id="login">

    <div class="lgInputBox">
      <input id="email" class="inputSty inputUtilStyle" type="text" placeholder="Email Address">
    </div>


    <div class="lgInputBox">
      <input class="inputStyPsd inputUtilStyle" type="password" placeholder="Password">
    </div>


    <div class="loginSubmit">SING IN</div>




  </div>
</template>
<style>
  @import "../css/user.css";
</style>

<script type="text/javascript">

  export default {
    data () {
      return {}
    },
    created: function () {

    },
    mounted: function () {
      let emailNode = document.getElementById('email');
      emailNode.focus();


    },
    methods: {}
  }


</script>


