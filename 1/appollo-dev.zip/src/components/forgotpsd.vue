<template>
  <div id="forgot">
    <forgot-title :message="forgotTitle"></forgot-title>

    <p class="forgotMsg rangPdding">
      Please input your email address.Click the link in the mail wesent your and reset you code.</p>

    <div class="marginTop marginBottom">
      <input type="text" v-model="forgotVal" placeholder="Email Address" name="" id="forgotSubmit">
    </div>
    <forgot-btn :buttonName="btnName" :buttonPath="btnPath" :queryPar="forgotVal"></forgot-btn>

  </div>
</template>
<style>

  @import "../css/mysass.css";
  @import "../css/cart.css";

  #forgotSubmit {
    border: none;
    width: 100%;
    height: 4.5rem;
    outline: none;
    padding: 1rem 2rem;
  }

  .forgotMsg {
    line-height: 2.5rem;
  }
</style>

<script type="text/javascript">
  import ForgotTitle from './share/back.vue';
  import Button from './share/button.vue';

  export default {
    data () {
      return {
        forgotTitle: 'Forgot Password',
        btnName: "Send Email",
        btnPath: "/forgotpsdmsg",
        forgotVal: ''
      }
    },
    computed: {},
    mounted: function () {

    },
    methods: {},
    components: {
      "forgot-title": ForgotTitle,
      "forgot-btn": Button
    },
    update: function () {
      console.log(555555555);
    }
  }


</script>


