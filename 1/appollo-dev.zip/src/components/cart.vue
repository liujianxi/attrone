<template>
  <div id="cart">


    <!--.............................................................-->
    <div class="cartTitleBox">
      <h4 class="cartTitle">
        Cart
      </h4>
      <div class="wishAndDel" dir="ltr">
        <span class="allDel" @click="allDel()">dl</span>
        <span class="wishAll">ws</span>
      </div>
    </div>

    <!--购物车列表-->
    <div>
      <div class="cartList" v-for="(item,index) in googsArr">
        <div class="checkboxSelect">
          <label class="checkbox"><input type="checkbox" v-model="item.goods"></label>
        </div>

        <div class="googsdetail">
          <img src="../assets/img/test.png" alt="">
          <div class="details">
            <p>aaaaaaaaa bbbbbbbbb bbbbbc cccc ddddd ddddd</p>
            <p class="detailColor">Color:Berry</p>
            <p class="detailPrice">${{amont}}</p>
            <p class="goodsQuantity">
              <button :disabled="quantity==1"
                      @click="goodsQuantitySub()"
                      :class="{goodsQuantitySub:true,fontColor:quantity==1}">-



              </button>
              <span class="goodsQuantityNum">{{quantity}}</span>
              <button @click="goodsQuantityAdd()" class="goodsQuantityAdd">+</button>
            </p>
            <p class="oprerating">
              <!--<span>2</span>-->
              <span class="opreratingWish">s</span>
              <span>x</span>
            </p>
          </div>
        </div>

      </div>
    </div>


    <!--结算方式-->
    <div class="goPay">
      <div class="goPayTop">
        <div class="goPayCheckBox">
          <label class="checkbox">
            <input type="checkbox"
                   @click="allSelect()"
                   v-model="allCheckBox">
          </label>
          <span>All</span>
        </div>
        <span>Sub Total : <span class="payMoney">{{allMoney}}</span></span>
      </div>
      <router-link :to="{path:'/checkout',query:{'title':'Check Out','amount':amont,'quantity':quantity,'totalPay':allMoney}}">
        <div class="checkOut">Check Out</div>
      </router-link>

    </div>

    <!--<p>{{ $t("message.hello") }}</p>-->


    <!--***************************-->
    <mt-datetime-picker
      ref="picker"
      type="datetime"
      date-format="{value}日"
      @confirm="handleConfirm"
      v-model="pickerValue">
    </mt-datetime-picker>


  </div>
</template>

<style>
  @import "../css/cart.css";
</style>


<script type="text/javascript">

  import Vue from 'vue'
  import { DatetimePicker } from 'mint-ui';
  Vue.component(DatetimePicker.name, DatetimePicker);


  //  <!--=================d===============------------->
  export default {
    data () {
      return {
        price: 0,
        quantity: 1,
        amont: 0,
        allCheckBox: false,
        allMoney: 0,
        googsArr: [{goods: false}, {goods: false}],
        pickerValue:''
      }
    },
    watch: {
      '$route': 'fetchData',
      pickerValue(o,n){
        console.log(o, n);
      }
    },
    methods: {
      allDel: function () {
        console.log('删除');
      },
      goodsQuantityAdd: function () {
        this.quantity++;
        this.amont = this.price * this.quantity;
        console.log(this.price);

      },
      goodsQuantitySub: function () {
        this.quantity--;
        this.amont = this.price * this.quantity;
        console.log(this.price);
      },
      allSelect: function () {

        if (this.allCheckBox == false) {
          this.allCheckBox = true;
          this.allMoney = this.price;
          for (let i = 0; i < this.googsArr.length; i++) {
            this.googsArr[i]['goods'] = true;

          }

        } else {
          this.allCheckBox = false;
          this.allMoney = 0;
          for (let i = 0; i < this.googsArr.length; i++) {
            this.googsArr[i]['goods'] = false;

          }
        }
      },
      fetchData: function () {
      },
      openPicker() {

        console.log(this.pickerValue);
        this.$refs.picker.open();

      },
      handleConfirm(){
        console.log('日期确定执行的函数：'+this.pickerValue);
      }
    },
    created: function () {
      this.price = 100.00;
      this.amont = this.price;
      console.log('cart');

    },
    mounted:function () {
      console.log('进入cart----》');
      this.openPicker()
    }
  }
</script>
