<template>
  <div id="wish">
    <p class="rangPdding fontSize textAlign bgWhite borderBottom titleClass">My WishList</p>
    <!--<mt-button type="danger" style="margin-top: 100px">default</mt-button>-->


    <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul class="currentPaying nameAddress" style="margin-bottom: 10rem;">
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
        <li class="currentPayingFlex">
          <div class="payImg">
            <img src="" alt="">
          </div>
          <div class="PayDetail">
            <p class="googsTitle">
              JJRC JJ - 1000 Headless Mode 6 Axis Gyro 2.4GHz 4CH RC Quadcopter RTF 3D Flip Flying UFO  -  BLUE</p>
            <p class="payMoney fontSize">$188.00</p>
            <span class="logMoney paddingLeft">$299.00</span>
            <span class="renColor"> 49% OFF</span>

            <div class="wishPosition">
              <span class="wishCart">d</span>
              <span class="wishShare">f</span>
              <span class="wishDel">g</span>
            </div>
          </div>
        </li>
      </ul>
    </mt-loadmore>

  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/cart.css";

  .logMoney {
    text-decoration: line-through;
    color: #999;
  }

  .wishPosition {
    position: absolute;
    bottom: 0;
    left: 0;
  }

</style>


<script type="text/javascript">
  import Vue from 'vue'

  import {Loadmore, Toast, Button} from 'mint-ui';


  Vue.component(Loadmore.name, Loadmore, Button.name, Button, Toast);

  export default {
    data () {
      return {
        'page': 1,
        "bottomAllLoaded": false,
        allLoaded: false,
        topPullText: 'yyyyyyyyyyyyy',
        topDropText: 'ccccccccccccccccccccccccccc',
      }
    },
    computed: {},
    methods: {
      loadTop(id) {

        this.$refs.loadmore.onTopLoaded(id);
        console.log(this.page++);
      },
      loadBottom(id){
        console.log(666);

        this.$refs.loadmore.onBottomLoaded(id);
      }
    },
    activated: function () {
      Toast('提示语');
      this.topPullText = '99999999999';


      let bodyNode = document.querySelector('body');
      setTimeout(function () {
        bodyNode.scrollTop = 0
      }, 100);


//      document.body.scrollTop = document.documentElement.scrollTop = 0;

//      location.href="url#app"

    },
    components: {
      Loadmore
    }
  }


</script>

