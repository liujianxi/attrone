<template>
  <div id="goodsList">
    <div class="listTitle">
      <div class="categoryBox borderBottom" style="display: flex;position: relative;">
        <div class="categorySearch mgCenter">
          <input id="categoriesSearch" type="text" placeholder="Search">
        </div>

        <div class="backStyle" @click="listBack()">dd</div>
      </div>
    </div>

    <!--list-->
    <div class="listContent">

      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>
      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount" v-if="false">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>
      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>
      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>
      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>
      <div class="marginBottom bgWhite borderLeft textAlign">

        <router-link class="" to="/goodsdetail">
          <img src="../assets/img/test.png" alt="">
        </router-link>

        <span class="discount">15% OFF</span>
        <div class="rangPdding marginTop">
          <p>
            <span class="renColor fontSize">$123.00</span>
            <span class="logMoney">$233.00</span>
          </p>
          <p class="wishQuantity paddingTop">
            <span @click="clickHeart()" :class="{heart:!heart_a,heart_on:heart_a}">ht</span>
            <span>666</span>
          </p>
        </div>

      </div>

    </div>

  </div>
</template>

<style>
  @import "../css/mysass.css";
  @import "../css/categories.css";

  .listTitle {
    /*background: linear-gradient(#000, #f00 50%, #090);*/
    background: #ff8000;
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 999;
  }

  .listContent {
    margin-top: 6.5rem;
    font-size: 0;
  }

  .listContent > div {
    width: 50%;
    display: inline-block;
    font-size: 1.6rem;
    height: 22rem;
    position: relative;
  }

  .listContent img {
    width: 100%;
  }

  .listContent a {
    width: 80%;
    height: auto;
  }

  .discount {
    position: absolute;
    top: 0;
    left: 0;
    overflow: hidden;
    width: 2.7rem;
    height: 3.8rem;
    background: url("../assets/img/discount.png");
    -webkit-background-size: 100% 100%;
    background-size: 100% 100%;
    font-size: 1.2rem;
    color: #f0f0f0 !important;
    margin: 0 1.5rem;

  }

  .logMoney {
    font-size: 1.2rem;
    text-decoration: line-through;
    color: #999;
  }

  .wishQuantity {
    color: #999;
    width: 100%;
    font-size: 1.4rem;
  }

  .heart {
    width: 2rem;
    height: 2rem;
    display: inline-block;
    background: url("../assets/img/heart.png");
    background-size: 100% 100%;
    color: transparent;
  }

  .heart_on {
    width: 2rem;
    height: 2rem;
    display: inline-block;
    background: url("../assets/img/heart_on.png");
    background-size: 100% 100%;
    color: transparent;
  }


</style>

<script type="text/javascript">

  export default {
    name: 'hello',
    data () {
      return {
        heart_a: false
      }
    },
    methods: {
      listBack: function () {
        window.history.go(-1);
      },
      clickHeart: function () {
//          click_heart
        if (this.heart_a) {
          this.heart_a = false;
        } else {
          this.heart_a = true;
        }

      }
    },
    created: function () {

    }
  }
</script>
