<template>

  <div id="homepage">
    <!--自定义loading-->
    <my-loading v-show="isShowHide"></my-loading>
    <!--自定义alert模块-->
    <my-alert :alertTitle="myAlert"></my-alert>


    <div id="searchBox">
      <div class="seartBackground">
        <input id="search" placeholder="Search" type="text">
      </div>
      <div class="massageBox">
        <router-link to="">
          <span class="massageIcon">
            <span class="massageIconBadge"></span>
          </span>
        </router-link>
      </div>
    </div>

    <!--轮播图-->
    <swiper id="swiperSty" :options="swiperOption" ref="mySwiperwwww">
      <!-- slides -->

      <swiper-slide v-for="item of resCarousel">
        <img :src="item.picUrl" alt="">
      </swiper-slide>

      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>


    <!--广告位   1-->
    <div class="navPosition">

      <p v-for="atv of resActive" class="homeActive">
        <router-link to="/goodsdetail">
          <img :src="atv.picUrl" alt="">
        </router-link>
      </p>

    </div>

    <!--活动时间 -->
    <div class="activityTime">

      <p class="clockImg clockBackground iconHeight" style="color: transparent;">d</p>

      <p>
        <span class="flashSale">Flash Sale</span>
        <span class="endIn">End In</span>
      </p>
      <p class="endTime" dir="ltr">
        <span>
          <span id="activeHour">00</span>
        </span>
        <b style="color: #000;">:</b>
        <span>
          <span id="activeMinute">00</span>
        </span>
        <b style="color: #000;">:</b>
        <span>
          <span id="activeSecond">00</span>
        </span>

      <p id="timeNode"></p>
      </p>
    </div>


    <!--广告位   2-->
    <div class="navPosition">

      <p v-for="atv of resFlashSale" class="homeActive">
        <router-link to="/goodsdetail">
          <img :src="atv.picUrl" alt="">
        </router-link>
      </p>

    </div>

    <!--*******New Arrivals****-->
    <div class="activityTime newArrivals">
      <p class="newArrivalsBg clockBackground" style="color: transparent;">d</p>
      <p>
        <span class="flashSale" style="font-size: 1.6rem;">New Arrivals</span>
      </p>
    </div>

    <div dir="rtl" class="newArrivalsList">

      <div v-for="val of resNewArrivals">
        <router-link to="/goodsdetail">
          <img :src="val.picUrl" alt="">

        </router-link>
      </div>

    </div>

    <!--*******Lift Style****-->
    <div class="activityTime newArrivals">
      <p class="liftStyleBg clockBackground" style="color: transparent;">d</p>
      <p>
        <span class="flashSale" style="font-size: 1.6rem;">Lift Style</span>
      </p>
    </div>


    <div v-if="resLifeStyle[0]!=null" class="liftStyleList">
      <div class="liftStylyTop">
        <div>
          <router-link to="/goodsdetail">
            <img :src="resLifeStyle[0].picUrl" alt="">
          </router-link>
        </div>
        <div>
          <router-link to="/goodsdetail">
            <img :src="resLifeStyle[1].picUrl" alt="">
          </router-link>
        </div>
      </div>
      <div class="liftStyleBottom">
        <div>
          <router-link to="/goodsdetail">
            <img :src="resLifeStyle[2].picUrl" alt="">
          </router-link>
        </div>
        <div>
          <router-link to="/goodsdetail">
            <img :src="resLifeStyle[3].picUrl" alt="">
          </router-link>
        </div>
      </div>
    </div>

    <!--*******Recommend****-->
    <div class="activityTime newArrivals">
      <p class="recommendBg clockBackground" style="color: transparent;">d</p>
      <p>
        <span class="flashSale" style="font-size: 1.6rem;">Recommend</span>
      </p>
    </div>

    <div class="recommendList">
      <div v-for="cm of resRecommend" class="recommendBox">
        <router-link to="/goodsdetail">
          <img v-lazy="cm.picUrl" alt="">
        </router-link>
      </div>
    </div>


    <!--到底时加载-->

    <ul
      v-infinite-scroll="loadMore"
      infinite-scroll-disabled="loading"
      infinite-scroll-distance="10">
      <li v-for="c of list">{{ c }}</li>
    </ul>


    <p class="endClass">Stop, in the end</p>
  </div>
</template>

<style scoped>
  @import "../css/mysass.css";
  @import "../css/homepage.css";
</style>


<script type="text/javascript">
  import Vue from 'vue'
  import {swiper, swiperSlide} from 'vue-awesome-swiper'
  //  import VueAwesomeSwiper from 'vue-awesome-swiper'
  import RequestUrl from '../service/config'
  import Loading from './share/loading.vue'
  import Alert from './share/alert.vue'
  import {Lazyload} from 'mint-ui';       //图片延迟加载
  import {InfiniteScroll} from 'mint-ui';


  Vue.use(Lazyload);
  Vue.use(InfiniteScroll);


  export default {

    name: 'homepage',
    data()
    {
      return {
        tabs: '',
        swiperOption: {
          autoplay: 2000,
          direction: 'horizontal',
          grabCursor: true,
          setWrapperSize: true,
          loop: true,
          pagination: '.swiper-pagination',
          paginationClickable: true,
          mousewheelControl: true,
          observeParents: true,

          onTransitionStart(swiper){
//            console.log(swiper, '轮播图');
          }
        },
        isShowHide: true,
        myAlert: '自定义Alert',
        aaadaf: 1,
        activeStart: '',
        activeEnd: '',
        activeTime: '',
        resCarousel: [],
        resActive: [],
        resFlashSale: [],
        resNewArrivals: [],
        resLifeStyle: [],
        resRecommend: [],
        pageNum: 1,
        list: [],
        loading: false
      }
    }
    ,
    computed: {
      uyyyyy: function () {
        console.log(2222);
      }

    }
    ,
    mounted(){

    }
    ,
    created: function () {


    }
    ,
    activated: function () {
//    let that = this;
////      上拉
//    window.onscroll = function () {
//      let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
//      let bodyHeight = document.getElementsByTagName('body')[0];
//      let screenHeight = window.screen.height;
//      let distanceBottom = bodyHeight.offsetHeight - scrollTop - screenHeight;
//      console.log(distanceBottom);
//
//      if (distanceBottom <= 0) {
////          console.log(this.pageNum++);
//          console.log(that.pageNum++   +'---->滚动条已到底，可以实现上拉跟新')
//      }
//    };


      this.homeRequestData()

    }
    ,
    methods: {
//      swiper(){
//          console.log("8888");
//        return this.$refs.mySwiperwwww.swiper
//      },


      homeRequestData: function () {
        this.isShowHide = true;
        let par = {"lan": "en"};
        RequestUrl.get("/v1/home/index", par).then(res => {
          console.log(res);

          if (res.code === 0) {
            this.isShowHide = false;

            this.resCarousel = res.data.carousel.list;
            this.resActive = res.data.active.list;
            this.resFlashSale = res.data.flashSale.list;
            this.resNewArrivals = res.data.newArrivals.list;
            this.resLifeStyle = res.data.lifeStyle.list;
            this.resRecommend = res.data.recommend.list;
            this.activeStart = res.data.flashSale.beginTime;
            this.activeEnd = res.data.flashSale.endTime;
            let that = this;
            let a = res.data.flashSale.endTime - new Date().getTime();

            if (a > 0) {    //判断活动时间是否结束  >0没结束

              let activeHourNode = document.querySelector('#activeHour');
              let activeMinuteNode = document.querySelector('#activeMinute');
              let activeSecondNode = document.querySelector('#activeSecond');
              let timerActive = setInterval(() => {
                let currentSub = this.activeEnd - new Date().getTime();
                let currentNew = new Date(currentSub);
                let currentHour = currentNew.getHours();
                let currentMinute = currentNew.getMinutes();
                let currentSecond = currentNew.getSeconds();
                if (currentHour < 10) {
                  currentHour = "0" + currentHour;
                }
                if (currentMinute < 10) {
                  currentMinute = "0" + currentMinute;
                }
                if (currentSecond < 10) {
                  currentSecond = "0" + currentSecond;
                }
                activeHourNode.innerHTML = currentHour;
                activeMinuteNode.innerHTML = currentMinute;
                activeSecondNode.innerHTML = currentSecond

              }, 1000)
            } else {
              clearInterval(timerActive)
            }


          }

        });
      },
      loadMore() {
        this.loading = true;

        let that = this;
        setTimeout(() => {

          let last = that.list[0] ? that.list[that.list.length - 1] : 0;

          console.log(that.list.length, '99', "pageNum" + this.pageNum++);
          for (let i = 1; i <= 10; i++) {

            that.list.push(last + i);
          }
          that.loading = false;
        }, 1000);
      }
    }
    ,
    components: {
      swiper,
      swiperSlide,
      "my-loading": Loading,
      "my-alert": Alert
    }

  }

</script>


