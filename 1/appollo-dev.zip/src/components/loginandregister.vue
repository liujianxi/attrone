<template>
  <div class="fullHeight" id="loginAndRegister">

    <div class="lgRegBox fullHeight fullWidth ft-cl">
      <span style="position: relative;top: 1rem;right: 1rem;" @click="closeLogin()" class="lg-cls"></span>


      <div class="lgReg">


        <div class="sl-lgOrReg paddingBottom marginBottom">


          <div @click="selectLgOrReg(1)" :class="{lgTitle:true,titleActive:slt==1}">
            <router-link to="/loginRegister/login">
              <p style="color: #fff;">Login</p>
            </router-link>
          </div>

          <div @click="selectLgOrReg(2)" :class="{regTitle:true, titleActive:slt==2}">
            <router-link to="/loginRegister/register">
              <p style="color: #fff;">Register</p>
            </router-link>
          </div>

        </div>


        <div>
          <keep-alive>
            <router-view></router-view>
          </keep-alive>
        </div>


      </div>


      <router-link v-show="forgot" class="gorogt" to="/forgotpsd">
        <p  class="toFindPsd borderTop">Forgot Password</p>
      </router-link>

    </div>



  </div>
</template>
<style>
  @import "../css/user.css";
</style>

<script type="text/javascript">

  export default {
    data () {
      return {
        slt: 1,
        pathName: 'login',
        forgot:true
      }
    },
    computed: {},
    created: function () {
//        this.selectLgOrReg()
      console.log(this.$route.name, this.slt);
    },
    methods: {
      closeLogin: function () {
        this.$router.push('/account')
      },
      selectLgOrReg: function (index) {
        console.log('还5555');
        if (index == 1) {
          this.slt = 1;
        } else {
          this.slt = 2;
        }

        if (this.$route.name == 'login' && this.slt == 2) {
          this.slt = 1;
        }


        if(this.$route.name=='login'){
            this.forgot=true

        }else {
            this.forgot=false;
        }


      }


    },
    updated:function (el) {
      if (this.$route.query.log){
          this.slt=1;
      }
    }
  }


</script>


