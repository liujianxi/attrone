<template>
  <div id="back">
    <div class="cartTitleBox" style="background: #efeff4;">
      <h4 class="cartTitle">
        {{message}}
      </h4>
      <div @click="goBackToHistory()" class="backSty"></div>
    </div>
  </div>
</template>

<style>
  @import "../../css/cart.css";
</style>

<script type="text/javascript">
  export default {
    props: ['message','toPath'],
    methods: {
      goBackToHistory: function () {
//        this.$router.push({path: this.toPath})
        window.history.go(-1);  //返回上一页
      }
    }
  }
</script>
