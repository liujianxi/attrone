<template>
  <div id="button">
    <router-link :to="{'path':buttonPath,query:{'email':queryPar}}">
      <div class="checkOut">{{buttonName}}</div>
    </router-link>
  </div>
</template>
<style>

</style>

<script type="text/javascript">
  export default {
    props: ['buttonName','buttonPath','queryPar'],
    methods: {

    }
  }
</script>
