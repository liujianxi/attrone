<template>
  <div v-if="alertShowHide" id="alert">
    <div @click="closeFn()" id="alertBg"
         style="position: fixed;background: rgba(0,0,0,0.3);height: 100%;width: 100%;z-index: 9999;">

      <div @click="stopPro()" class="alertModule">
        <span @click="closeFn()" class="closeBtn"></span>
        <span>{{alertTitle}}</span>
      </div>

    </div>
  </div>
</template>
<style>
  #alert {
    height: 100%;

  }

  .alertModule {
    width: 16rem;
    line-height: 10rem;
    position: fixed;
    top: 30%;
    background: #ffffff;
    left: 50%;
    margin-left: -8rem;
    border: 1px solid #ff8000;
    z-index: 168;
    text-align: center;
    border-radius: 0.5rem;
  }

  .closeBtn {
    content: '';
    display: block;
    padding: 1rem;
    margin: 0.5rem;
    background: url("../../assets/img/close_detail.png") center no-repeat;
    background-size: 80% 80%;
    position: absolute;
  }

</style>

<script type="text/javascript">
  export default {
    data(){
      return {
        alertShowHide: true
      }
    },
    props: ['alertTitle'],
    methods: {
      closeFn: function () {
        this.alertShowHide = false;
      },
      stopPro: function () {


      },
      closeCallBack: function (even) {
        even.stopPropagation();
      }
    },
    mounted: function () {
      let childNode = document.getElementsByClassName('alertModule')[0];
      childNode.addEventListener('click', this.closeCallBack)
    },
    created:function () {
//      alert(1)

    },
    activated: function () {

    }
  }
</script>
