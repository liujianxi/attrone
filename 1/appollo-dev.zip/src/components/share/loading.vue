<template>
  <div id="loading">
    <div style="position: fixed;background: rgba(0,0,0,0.3);height: 100%;width: 100%;z-index: 9999;">

      <div class="loadActive"></div>
    </div>
  </div>
</template>
<style>
  #loading {
    height: 100%;
  }

  .loadActive {
    display: inline-block;
    height: 6rem;
    width: 6rem;
    border-top: 8px solid #ff8000;
    border-bottom: 8px solid #aba6a6;
    border-left: 8px solid #aba6a6;
    border-right: 8px solid #aba6a6;
    position: absolute;
    border-radius: 50%;
    margin-left: -3rem;
    left: 50%;
    top: 30%;
    animation: loading 1s linear infinite;
  }

  @keyframes loading {
    0% {
      transform: rotate(0deg)
    }
    50% {
      transform: rotate(180deg)
    }
    100% {
      transform: rotate(360deg)
    }
  }


</style>

<script type="text/javascript">
  export default {
    props: [],
    methods: {}
  }
</script>
