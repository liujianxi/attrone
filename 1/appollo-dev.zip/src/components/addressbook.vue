<template>
  <div id="addressbook">
    <address-title class="titleClass" :message="forgotTitle"></address-title>
    <!--<p class="addressDone rangPdding">Done</p>-->
    <ul class="nameAddress">
      <li class="ovflowHidden borderBottom paddingBottom">
        <p class="ovflowHidden lineHeight">
          <span class="fontSize floatRight">Name</span>
          <span class="floatLeft renColor">Default Adress</span>
        </p>
        <p>SlideShare Inc., 490 2nd St, Suite 300, San Francisco, CA 94107</p>
        <p class="lineHeight">1234567890</p>
        <p class="floatLeft">
          <router-link to="/newaddress" style="display: inline;">
            <span class="addressEdit marginLeft">ed</span>
          </router-link>
          <span class="wishDel marginLeft">del</span>
        </p>
      </li>
      <li class="ovflowHidden borderBottom paddingBottom">
        <p class="ovflowHidden lineHeight">
          <span class="fontSize floatRight">Name</span>
          <span class="floatLeft renColor">Default Adress</span>
        </p>
        <p>SlideShare Inc., 490 2nd St, Suite 300, San Francisco, CA 94107</p>
        <p class="lineHeight">1234567890</p>
        <p class="floatLeft">
          <router-link to="/newaddress" style="display: inline;">
            <span class="addressEdit marginLeft">ed</span>
          </router-link>
          <span class="wishDel marginLeft">del</span>
        </p>
      </li>
      <li class="ovflowHidden borderBottom paddingBottom">
        <p class="ovflowHidden lineHeight">
          <span class="fontSize floatRight">Name</span>
          <span class="floatLeft renColor">Default Adress</span>
        </p>
        <p>SlideShare Inc., 490 2nd St, Suite 300, San Francisco, CA 94107</p>
        <p class="lineHeight">1234567890</p>
        <p class="floatLeft">
          <router-link to="/newaddress" style="display: inline;">
            <span class="addressEdit marginLeft">ed</span>
          </router-link>
          <span class="wishDel marginLeft">del</span>
        </p>
      </li>
      <li class="ovflowHidden borderBottom paddingBottom">
        <p class="ovflowHidden lineHeight">
          <span class="fontSize floatRight">Name</span>
          <span class="floatLeft renColor">Default Adress</span>
        </p>
        <p>SlideShare Inc., 490 2nd St, Suite 300, San Francisco, CA 94107</p>
        <p class="lineHeight">1234567890</p>
        <p class="floatLeft">
          <router-link to="/newaddress" style="display: inline;">
            <span class="addressEdit marginLeft">ed</span>
          </router-link>
          <span class="wishDel marginLeft">del</span>
        </p>
      </li>
      <li class="ovflowHidden borderBottom paddingBottom">
        <p class="ovflowHidden lineHeight">
          <span class="fontSize floatRight">Name</span>
          <span class="floatLeft renColor">Default Adress</span>
        </p>
        <p>SlideShare Inc., 490 2nd St, Suite 300, San Francisco, CA 94107</p>
        <p class="lineHeight">1234567890</p>
        <p class="floatLeft">
          <router-link to="/newaddress" style="display: inline;">
            <span class="addressEdit marginLeft">ed</span>
          </router-link>
          <span class="wishDel marginLeft">del</span>
        </p>
      </li>
    </ul>

    <address-btn class="footerButton borderTop" :buttonName="buttonName" :buttonPath="buttonPath"></address-btn>
  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/cart.css";
  @import "../css/myorder.css";
</style>


<script type="text/javascript">
  import AddressBook from './share/back.vue'
  import AddressBtn from  './share/button.vue'

  export default {
    data () {
      return {
        forgotTitle: 'Address Book',
        titles: '',
        buttonName: 'Add New Address',
        buttonPath: '/newaddress'
      }
    },
    computed: {},
    methods: {},
    components: {
      "address-title": AddressBook,
      "address-btn": AddressBtn,
    }
  }


</script>

