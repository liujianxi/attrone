<template>
  <div id="shipped">

    <ul>
      <li class="rangPdding paddingBottom bgWhite marginBottom">
        <p class="grayColor lineHeight">00:00:00 12:12:12</p>

        <router-link class="orderUnpaid" to="/goodsdetail">
          <div class="imgBox">
            <img class="fullWidth" src="../assets/img/test.png" alt="">
          </div>
          <div class="msgbox">
            <p class="unpaidTitle lineHeight">
              Google's free service instantly translates words, phrases, and web pages between English and over 100 other languages.</p>
            <p class="grayColor lineHeight">Color:blue  Size:L</p>
            <p>
              <span class="floatRight">$188.00</span>
              <span class="floatLeft">X2</span>
            </p>
            <p class="lineHeight floatLeft">One Item Order Total : $376.00</p>

          </div>
        </router-link>

        <p style="width: 100%;text-align: left;overflow: hidden;">
          <span style="width: 14rem;" class="floatLeft lineHeight payBtn marginTop marginLeft">Confirm Order</span>
        </p>
      </li>
      <li class="rangPdding paddingBottom bgWhite marginBottom">
        <p class="grayColor lineHeight">00:00:00 12:12:12</p>

        <router-link class="orderUnpaid" to="/goodsdetail">
          <div class="imgBox">
            <img class="fullWidth" src="../assets/img/test.png" alt="">
          </div>
          <div class="msgbox">
            <p class="unpaidTitle lineHeight">
              Google's free service instantly translates words, phrases, and web pages between English and over 100 other languages.</p>
            <p class="grayColor lineHeight">Color:blue  Size:L</p>
            <p>
              <span class="floatRight">$188.00</span>
              <span class="floatLeft">X2</span>
            </p>
            <p class="lineHeight floatLeft">One Item Order Total : $376.00</p>

          </div>
        </router-link>

        <p style="width: 100%;text-align: left;overflow: hidden;">
          <span style="width: 14rem;" class="floatLeft lineHeight payBtn marginTop marginLeft">Confirm Order</span>
        </p>
      </li>
      <li class="rangPdding paddingBottom bgWhite marginBottom">
        <p class="grayColor lineHeight">00:00:00 12:12:12</p>

        <router-link class="orderUnpaid" to="/goodsdetail">
          <div class="imgBox">
            <img class="fullWidth" src="../assets/img/test.png" alt="">
          </div>
          <div class="msgbox">
            <p class="unpaidTitle lineHeight">
              Google's free service instantly translates words, phrases, and web pages between English and over 100 other languages.</p>
            <p class="grayColor lineHeight">Color:blue  Size:L</p>
            <p>
              <span class="floatRight">$188.00</span>
              <span class="floatLeft">X2</span>
            </p>
            <p class="lineHeight floatLeft">One Item Order Total : $376.00</p>

          </div>
        </router-link>

        <p style="width: 100%;text-align: left;overflow: hidden;">
          <span style="width: 14rem;" class="floatLeft lineHeight payBtn marginTop marginLeft">Confirm Order</span>
        </p>
      </li>
    </ul>


  </div>
</template>
<style>
  @import "../css/mysass.css";
  @import "../css/user.css";
</style>

<script type="text/javascript">

  export default {
    data () {
      return {}
    },
    computed: {},
    mounted: function () {

    },
    methods: {},


  }


</script>


