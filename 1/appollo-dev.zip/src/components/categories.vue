<template>
  <div id="categories">
    <!--search-histoty-Box-->
    <div :style="{display:showHistory}" class="historyBox fullHeight fullWidth rangPdding">
      <div class="categoryBox borderBottom" style="display: flex;position: relative;">
        <div class="categorySearch">
          <input id="categoriesSearch" type="text" placeholder="Search">
        </div>

        <div class="searchClose" @click="searchClose()"></div>
      </div>
<!--hot-search-->
      <div class="borderBottom">
        <p class="rangPdding">Hot Search</p>
        <div class="rangPdding">

          <router-link style="display: inline;" to="/list">
            <span class="hotSearch borderAll">服装</span>
          </router-link>


          <router-link style="display: inline;" to="/list">
            <span class="hotSearch borderAll">衣服</span>
          </router-link>


          <router-link style="display: inline;" to="/list">
            <span class="hotSearch borderAll">美食</span>
          </router-link>


        </div>
      </div>

<!--search-history-->
      <div class="borderBottom">
        <p class="rangPdding ovflowHidden">
          <span>Search History</span>
          <button @click="clearHistory()" class="floatLeft historyDel">uuuu</button>
        </p>
        <div class="rangPdding">

          <router-link style="display: inline;" to="/list">
            <span class="hotSearch borderAll">服装</span>
          </router-link>

          <router-link style="display: inline;" to="/list">
            <span class="hotSearch borderAll">衣服</span>
          </router-link>

        </div>


      </div>

    </div>


    <!--category-List-->
    <div class="categoryBox">
      <div class="categorySearch marginTop">
        <input readonly @click="startSearch()" type="text" placeholder="Search">
      </div>
    </div>

    <div class="categoryList">

      <router-link to="/goodsList">
        <p>
          <span class="categroyTitle">Categroy</span>
        </p>
      </router-link>

      <router-link to="/goodsList" style="border-left: 1px solid #e6e6e6;border-right: 1px solid #e6e6e6;">
        <p>
          <span class="categroyTitle">Categroy</span>
        </p>
      </router-link>
      <router-link to="/goodsList">
        <p>
          <span class="categroyTitle">Categroy</span>
        </p>
      </router-link>
      <router-link to="/goodsList">
        <p>
          <span class="categroyTitle">Categroy</span>
        </p>
      </router-link>

    </div>

  </div>
</template>
<style>

  @import "../css/mysass.css";
  @import "../css/categories.css";
</style>

<script type="text/javascript">

  export default {
    data () {
      return {
        showHistory: 'none'
      }
    },
    computed: {},
    methods: {
      startSearch: function () {
        this.showHistory = 'block';
        let searchNode=document.getElementById('categoriesSearch');
        setTimeout(function () {
          searchNode.focus();
        },100)


      },
      searchClose: function () {
        this.showHistory = 'none';
      },
      clearHistory:function () {
        console.log('清除历史记录');
      }

    },
    mounted:function () {

    }
  }


</script>


