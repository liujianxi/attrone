<template>
  <div id="accountset">
    <set-back class="titleClass" :message="childTitle" :toPath="toBackPath"></set-back>


    <ul class="accountBottom marginTopTitle">
      <li class="myOrder" v-for="item of $t('message.accountSet')">
        <router-link :to="item.link">
          <span :class="{afterEle:true,ltrFr:gLang!==2,ltrDegr:gLang!==2}"></span>
          <span>{{item.name}}</span>
          <span class="floatLeft currentSet">{{item.msg}}</span>
        </router-link>
      </li>
    </ul>

    <!--<ul class="accountBottom marginTop">-->
      <!--<li class="myOrder" v-for="item of aboutApp">-->
        <!--<router-link :to="item.link">-->
          <!--<span class="afterEle"></span>-->
          <!--<span>{{item.name}}</span>-->
        <!--</router-link>-->

      <!--</li>-->
    <!--</ul>-->


  </div>
</template>


<style scoped>
  @import "../css/ltr.css";
  @import "../css/mysass.css";
  @import "../css/user.css";


</style>

<script type="text/javascript">
  import SetBack from './share/back.vue'


  let selectTitle = [
    {name: "Language", link: '/language', msg: ''},
    {name: "Currency", link: '/currency', msg: 'USD'},
    {name: "Push Norifycations", link: '/home', msg: ''},
//    {name:"Clear Cache[wap端无此选项]",link:'/home',msg:''},
    {name: "About Aplo", link: '/home', msg: ''}
  ];


  let aboutApp = [
    {name: "Check new version", link: '/home'},
    {name: "Rate APP", link: '/home'}
  ];

  export default {
    data () {
      return {
        "childTitle": 'Setting',
        "toBackPath": '',
        "selectTitle": selectTitle,
        "aboutApp": aboutApp

      }
    },
    computed: {},
    methods: {},
    components: {
      "set-back": SetBack
    }
  }


</script>

