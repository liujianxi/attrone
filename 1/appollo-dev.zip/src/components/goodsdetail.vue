<template>
  <div class="goodsdetail">
    <title-back class="titleClass" :message="childTitle" :toPath="toBackPath"></title-back>
    <!--顶部-->
    <div class="toHomeShare">
      <router-link to="/home">
        <span class="toHome">h</span>
      </router-link>

      <router-link to="/cart">
        <span class="toShare">y</span>
      </router-link>

    </div>

    <!--image-->

    <swiper style="margin-top: 3.6rem;" :options="swiperOption" ref="mySwiper">
      <!-- slides -->
      <swiper-slide style="background: blue;">
        <p>详情</p>
        <p>详情</p>
        <p>详情</p>
        <p>详情</p>
        <p>详情</p>
        <p>详情</p>
        <p>详情</p>
      </swiper-slide>
      <swiper-slide style="background: #c0c0c0;">
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
        <p>I'm Slide 2</p>
      </swiper-slide>
      <swiper-slide style="background: #42b983;">
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p>
        <p>I'm Slide 3</p></swiper-slide>
      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>


    <div class="rangPadding moneyDetail">
      <div class="mdRight">
        <p class="nowMoney">$148.00</p>
        <p class="historyMoney">$238.00</p>
        <p class="discount">76% OFF</p>

      </div>
      <!--点击收藏到心愿箱-->
      <div class="wishQuantity">
        <span @click="myWish()" :class="{wishHeartClose:clickToWishBox,wishHeartOpen:!clickToWishBox}">h</span>
        <span class="wishNumber">123</span>

      </div>
    </div>
    <p class="goodsMsg">
      View the profiles of people named Lotooa Ddsaf. Join Facebook to connect with Lotooa Ddsaf and others you may know. </p>


    <ul class="accountMyOrder">
      <li class="myOrder">
        <span class="afterEle"></span>
        <span>Description</span>
      </li>

      <li class="myOrder">
        <span class="afterEle"></span>
        <span>Specifications</span>
      </li>

    </ul>


    <div class="addToCart">


      <router-link class="myCart" to="/cart">
        <span class="cartIcon">yyy</span>
        <span class="addcartTitle">Cart</span>
        <span class="addCartBadge">6</span>
      </router-link>
      <p @click="showAddToCartBtn()" class="cartBotton">Add To Cart</p>
    </div>


    <!--select-->

    <div :class="{orderDetail:true, orderDetailShow:orderDetailShowHide}">
      <p @click="clickClose()" class="close"></p>

      <p class="goodsSmallImg">
        <img src="" alt="">
      </p>
      <span class="goodsRealyMoney">$148.00</span>
      <ul class="colorAndSize borderTops">
        <li class="borderBottom">
          <p class="fontSize marginTop marginBottom">Color</p>
          <p class="colorSelect marginBottom">
            <span>Black</span>
            <span>Blue</span>
            <span>Red</span>
          </p>
        </li>
        <li class="borderBottom marginTop paddingBottom">

          <p class="fontSize paddingTop">Size</p>
          <p class="sizeSelect marginTop">
            <span>XS</span>
            <span>S</span>
            <span>M</span>
            <span>L</span>
          </p>


        </li>


        <li class="borderBottom marginTop paddingBottom">

          <p class="fontSize paddingTop">Quantity</p>
          <p class="marginTop borderAll quantitySelect">
            <button :class="{rangPadding:true,wishNumber:selectQuantity==1}"
                    @click="subQuantity()"
                    :disabled="selectQuantity==1">-
            </button>
            <span class="rangPadding borderLeft borderRight">{{selectQuantity}}</span>
            <button @click="addQuantity()" class="rangPadding">+</button>
          </p>

        </li>




      </ul>

      <div class="goodsSubmit" @click="detaiSunmit()">
        Submit
      </div>
    </div>


  </div>
</template>

<style>
  @import "../css/goods.css";
  @import "../css/cart.css";
  @import "../css/user.css";
</style>
<script type="text/javascript">
  import Vue from 'vue'
  import {swiper, swiperSlide} from 'vue-awesome-swiper'
  import Back from './share/back.vue'
  export default {
    name: 'hello',
    data () {
      return {
        childTitle: 'add to cart',
        toBackPath: '',
        swiperOption: {
          autoplay: 6000,
          direction: 'horizontal',
          grabCursor: true,
          setWrapperSize: true,
          loop: true,
          pagination: '.swiper-pagination',
          paginationClickable: true,
          mousewheelControl: true,
          observeParents: true,
          onTransitionStart(swiper){
//            console.log(swiper, '轮播图');
          }
        },
        clickToWishBox: true,
        orderDetailShowHide: false,
        selectQuantity:1
      }
    },
    methods: {
      myWish() {

        if (this.clickToWishBox) {
          this.clickToWishBox = false;
        } else {
          this.clickToWishBox = true;
        }


        console.log("点击收藏wish");
      },
      showAddToCartBtn() {
        this.orderDetailShowHide = true;
      },
      clickClose() {
        this.orderDetailShowHide = false;
      },
      addQuantity() {
        this.selectQuantity++;
      },
      subQuantity() {
        this.selectQuantity--;
      },
      detaiSunmit(){
        console.log(this.selectQuantity,'数量');
        this.clickClose();
      }
    },
    created: function () {

      console.log('详情');
    },
    components: {
      'title-back': Back,
      swiper,
      swiperSlide
    }
  }
</script>
