<template>
  <div id="payment">
    <h1>payment</h1>

  </div>
</template>


<script type="text/javascript">

    export default {
        data () {
            return {
            }
        },
        computed:{
            uyyyyy:function () {
                console.log('payment');
            }
        },
        methods:{

        }
    }







</script>

<style>
</style>
