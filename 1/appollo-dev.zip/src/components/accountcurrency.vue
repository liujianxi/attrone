<template>
  <div id="accountcurrency">
    <set-back class="titleClass" :message="childTitle" :toPath="toBackPath"></set-back>


    <ul class="accountBottom marginTopTitle">
      <li @click="selectLanguage(index)" class="myOrder" v-for="(item,index) of selectLang">
        <span :class="{floatRight:true,usdCurrency:index==1,sarCurrency:index==0}">hb</span>
        <span class="languageName">{{item.name}}</span>
        <span :class="{floatLeft:true,sarLanguageOn:selectDot==index,sarLanguage:selectDot!=index}">st</span>
      </li>
    </ul>
  </div>
</template>

<style>
  @import "../css/mysass.css";
  @import "../css/user.css";

</style>

<script type="text/javascript">
  import SetBack from './share/back.vue'

  let selectLang = [
    {name: "SAR", msg: '', code: 0},
    {name: "USD", msg: 'USD', code: 1},
  ];


  export default {
    data () {
      return {
        "childTitle": 'Currency',
        "toBackPath": '',
        "selectLang": selectLang,
        "selectDot": 0

      }
    },
    computed: {},
    methods: {
      selectLanguage: function (index) {
        this.selectDot = index;
      }
    },
    components: {
      "set-back": SetBack
    }
  }


</script>

