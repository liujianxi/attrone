import Vue from 'vue'
import Router from 'vue-router'
import HomePage from '@/components/homepage'
import Wish from '@/components/wish'
import Categories from '@/components/categories'
import Cart from '@/components/cart'
import Checkout from '@/components/cartcheckout'
import Account from '@/components/account'
import Payment from '@/components/payment'
import Goodsdetail from '@/components/goodsdetail'
import LoginRegister from '@/components/loginandregister'
import Login from '@/components/login'
import Register from '@/components/register'
import GoodsList from '@/components/goodslist'
import ForgotPsd from '@/components/forgotpsd'
import ForgotMsg from '@/components/forgotpsdmsg'
import MyOrder from '@/components/myorder'
import MyOrderAll from '@/components/myorderall'
import MyOrderUnpaid from '@/components/myorderunpaid'
import MyOrderPreparing from '@/components/myorderpreparing'
import MyOrderShipped from '@/components/myordershipped'
import MyOrderReview from '@/components/myorderreview'
import AccountSet from '@/components/accountset'
import AccountLanguage from '@/components/accountlanguage'
import AccountCurrency from '@/components/accountcurrency'
import AdressBook from '@/components/addressbook'
import NewAddress from '@/components/addressnewaddress'
import Myinfo from '@/components/myinfo'
import ContactUs from '@/components/accountcontactus'
import ChangePassword from '@/components/accountchangepassword'
import DisplayName from '@/components/accountdisplayname'

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomePage
    }, {
      path: '/home',
      name: 'home',
      component: HomePage
    }, {
      path: '/wish',
      name: 'wish',
      component: Wish
    }, {
      path: '/categories',
      name: 'categories',
      component: Categories
    }, {
      path: '/Cart',
      name: 'cart',
      component: Cart
    }, {
      path: '/checkout',
      name: 'checkout',
      component: Checkout
    }, {
      path: '/account',
      name: 'account',
      component: Account
    }, {
      path: '/payment',
      name: 'payment',
      component: Payment
    }, {
      path: '/goodsdetail',
      name: 'goodsdetail',
      component: Goodsdetail
    }, {
      path: '/loginRegister',
      name: 'loginRegister',
      component: LoginRegister,
      children: [
        {path: '/loginRegister', component: Login, name: "login"},
        {path: '/loginRegister/login', component: Login, name: "login"},
        {path: '/loginRegister/register', component: Register, name: "register"}
      ]
    }, {
      path: '/list',
      name: 'list',
      component: GoodsList
    }, {
      path: '/forgotpsd',
      name: 'forgotpsd',
      component: ForgotPsd
    }, {
      path: '/forgotpsdmsg',
      name: 'forgotpsdmsg',
      component: ForgotMsg
    }, {
      path: '/myorder',
      name: 'myorder',
      component: MyOrder,
      children: [
        {path: '/myorder', component: MyOrderAll, name: "myorderall"},
        {path: '/myorder/all', component: MyOrderAll, name: "myorderall"},
        {path: '/myorder/unpaid', component: MyOrderUnpaid, name: "myorderunpaid"},
        {path: '/myorder/preparing', component: MyOrderPreparing, name: "myorderpreparing"},
        {path: '/myorder/shipped', component: MyOrderShipped, name: "myordershipped"},
        {path: '/myorder/review', component: MyOrderReview, name: "myorderreview"}
      ]
    }, {
      path: '/set',
      name: 'set',
      component: AccountSet
    }, {
      path: '/language',
      name: 'language',
      component: AccountLanguage
    }, {
      path: '/currency',
      name: 'currency',
      component: AccountCurrency
    }, {
      path: '/addressbook',
      name: 'addressbook',
      component: AdressBook
    }, {
      path: '/newaddress',
      name: 'newaddress',
      component: NewAddress
    }, {
      path: '/myinfo',
      name: 'myinfo',
      component: Myinfo
    },{
      path: '/contactus',
      name: 'contactus',
      component: ContactUs
    },{
      path: '/changePassword',
      name: 'changePassword',
      component: ChangePassword
    },{
      path: '/displayName',
      name: 'displayName',
      component: DisplayName
    }
  ]
})

// router.beforeEach((to, from, next) => {
//   console.log('测试');
//   // next('/order')
// });
