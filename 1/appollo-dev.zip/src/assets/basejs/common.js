export default {
  setLocalStorage: function (name) {
    console.log(name);
  },
  setCookie: function (name, data, days) {
    // days==>>>>>判断是否设置过期时间
    if (days) {
      let todayTime = new Date().getTime();
      let daysNum = days * (24 * 3600 * 1000);
      let expiresTime = new Date(todayTime + daysNum);
      document.cookie = name + '=' + JSON.stringify(data) + ';expires=' + expiresTime;
    } else {
      document.cookie = name + '=' + JSON.stringify(data)
    }

  },
  getCookie: function (name) {

    let docCookieArr = document.cookie.split(';');
    let reg = /.*\=/;
    let regName = /\=.*$/;
    let blank = /\s/;
    name.replace(blank, '');

    for (let i in docCookieArr) {

      let nameCookie = (docCookieArr[i].replace(regName, '')).replace(blank, '');

      let dataCookie = docCookieArr[i].replace(reg, '');


      if (name === nameCookie) {

        return JSON.parse(dataCookie);

      }

    }


  },
  clearCookie: function (name) {
    document.cookie = name + '="";expires=' + new Date('1970-01-01');
    return true;
  }
}
